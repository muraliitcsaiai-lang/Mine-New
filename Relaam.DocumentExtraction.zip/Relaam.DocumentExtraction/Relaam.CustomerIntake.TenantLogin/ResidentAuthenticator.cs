using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace Relaam.CustomerIntake.TenantLogin;

public interface IResidentAuthenticator
{
    Task<bool> IsValidAsync(string sCode, string hmy, CancellationToken cancellationToken);
}

/// <summary>Development-only fixed credentials loaded from appsettings.Development.json/user secrets.</summary>
public sealed class StaticResidentAuthenticator(IConfiguration configuration) : IResidentAuthenticator
{
    private readonly string _sCode = configuration["CustomerAuthentication:Static:SCode"] ?? "";
    private readonly string _hmy = configuration["CustomerAuthentication:Static:Hmy"] ?? "";

    public Task<bool> IsValidAsync(string sCode, string hmy, CancellationToken cancellationToken)
    {
        if (_sCode.Length == 0 || _hmy.Length == 0) return Task.FromResult(false);
        return Task.FromResult(SecretEquals(_sCode, sCode) & SecretEquals(_hmy, hmy));
    }

    private static bool SecretEquals(string expected, string actual)
    {
        var expectedHash = SHA256.HashData(Encoding.UTF8.GetBytes(expected));
        var actualHash = SHA256.HashData(Encoding.UTF8.GetBytes(actual));
        return CryptographicOperations.FixedTimeEquals(expectedHash, actualHash);
    }
}

/// <summary>Yardi-specific mapping is isolated behind dbo.VerifyResidentCredential.</summary>
public sealed class YardiResidentAuthenticator(CustomerDirectoryContext directory) : IResidentAuthenticator
{
    public async Task<bool> IsValidAsync(string sCode, string hmy, CancellationToken cancellationToken)
    {
        var rows = await directory.VerificationResults.FromSqlInterpolated($@"
                EXEC dbo.VerifyResidentCredential
                    @SCode = {sCode},
                    @Hmy = {hmy}")
            .AsNoTracking()
            .ToListAsync(cancellationToken);
        return rows.SingleOrDefault()?.IsValid == true;
    }
}
