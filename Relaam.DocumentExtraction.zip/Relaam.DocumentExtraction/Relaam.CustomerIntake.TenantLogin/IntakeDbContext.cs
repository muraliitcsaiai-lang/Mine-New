using Microsoft.EntityFrameworkCore;

namespace Relaam.CustomerIntake.TenantLogin;

public sealed class IntakeDbContext(DbContextOptions<IntakeDbContext> options) : DbContext(options)
{
    public DbSet<YardiCustomer> YardiCustomers => Set<YardiCustomer>();
    public DbSet<CustomerSession> CustomerSessions => Set<CustomerSession>();
    public DbSet<CustomerSubmission> Submissions => Set<CustomerSubmission>();
    public DbSet<SubmissionDocument> Documents => Set<SubmissionDocument>();
    public DbSet<StagedCustomerDocument> StagedDocuments => Set<StagedCustomerDocument>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CustomerSession>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.TokenHash).IsUnique();
            entity.Property(x => x.TokenHash).HasMaxLength(64).IsRequired();
            entity.Property(x => x.SCode).HasMaxLength(100).IsRequired();
            entity.Property(x => x.TCode).HasMaxLength(100).IsRequired();
            entity.HasOne<YardiCustomer>().WithMany().HasForeignKey(x => new { x.Hmy, x.TCode })
                .HasPrincipalKey(x => new { x.Hmy, x.TCode }).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<YardiCustomer>(entity =>
        {
            entity.ToTable("YardiCustomers", table =>
                        table.HasTrigger("TR_YardiCustomers_SetDtUpdated"));
            entity.HasKey(x => new { x.Hmy, x.TCode });
            entity.HasIndex(x => x.TCode).IsUnique();
            entity.Property(x => x.TCode).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
            entity.Property(x => x.DtCreated).HasDefaultValueSql("SYSUTCDATETIME()");
            entity.Property(x => x.IsSubmitted).HasDefaultValue(false);
            entity.Property(x => x.DtUpdated).HasDefaultValueSql("SYSUTCDATETIME()");
            entity.Property(x => x.IsExpired).HasDefaultValue(false);
            entity.Property(x => x.CustomerType);
        });
        modelBuilder.Entity<CustomerSubmission>(entity =>
        {
            entity.ToTable("CustomerIntakeRecords");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.SCode).IsUnique();
            entity.Property(x => x.SCode).HasMaxLength(100).IsRequired();
            entity.Property(x => x.TCode).HasMaxLength(100).IsRequired();
            entity.Property(x => x.LegalEntityName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.TinCiphertext).HasMaxLength(300).IsRequired();
            entity.Property(x => x.TrnCiphertext).HasMaxLength(300);
            entity.Property(x => x.CustomerType).HasMaxLength(30).IsRequired();
            entity.Property(x => x.TradeLicenseNumber).HasMaxLength(300).IsRequired();
            entity.Property(x => x.TradeLicenseIssuingAuthority).HasMaxLength(200).IsRequired();
            entity.Property(x => x.RegisteredAddressLine1).HasMaxLength(300).IsRequired();
            entity.Property(x => x.City).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Emirate).HasMaxLength(100).IsRequired();
            entity.Property(x => x.CountryCode).HasMaxLength(2).IsRequired();
            entity.Property(x => x.EInvoicingWave).HasMaxLength(50).IsRequired();
            entity.Property(x => x.ApprovedBy).HasMaxLength(100);
            entity.HasOne<YardiCustomer>().WithMany().HasForeignKey(x => new { x.Hmy, x.TCode })
                .HasPrincipalKey(x => new { x.Hmy, x.TCode }).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<SubmissionDocument>(entity =>
        {
            entity.ToTable("SubmissionDocuments");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => new { x.SubmissionId, x.Kind }).IsUnique();
            entity.Property(x => x.Kind).HasMaxLength(30).IsRequired();
            entity.Property(x => x.ContentType).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Extension).HasMaxLength(5).IsRequired();
            entity.HasOne<CustomerSubmission>().WithMany().HasForeignKey(x => x.SubmissionId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<StagedCustomerDocument>(entity =>
        {
            entity.ToTable("StagedCustomerDocuments");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => new { x.Hmy, x.TCode, x.Kind, x.Ordinal }).IsUnique();
            entity.Property(x => x.TCode).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Kind).HasMaxLength(40).IsRequired();
            entity.Property(x => x.ContentType).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Extension).HasMaxLength(5).IsRequired();
            entity.HasOne<YardiCustomer>().WithMany().HasForeignKey(x => new { x.Hmy, x.TCode })
                .HasPrincipalKey(x => new { x.Hmy, x.TCode }).OnDelete(DeleteBehavior.Cascade);
        });
    }
}

public sealed class YardiCustomer
{
    public long Hmy { get; set; }
    public string TCode { get; set; } = "";
    public string Name { get; set; } = "";
    public DateTimeOffset DtCreated { get; set; }
    public bool IsSubmitted { get; set; }
    public DateTimeOffset DtUpdated { get; set; }
    public bool IsExpired { get; set; }

    public Int32 CustomerType { get; set; }
}

public sealed class CustomerSession
{
    public Guid Id { get; set; }
    public string TokenHash { get; set; } = "";
    public string SCode { get; set; } = "";
    public long Hmy { get; set; }
    public string TCode { get; set; } = "";
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset ExpiresAtUtc { get; set; }
    public DateTimeOffset? RevokedAtUtc { get; set; }
}

public sealed class CustomerSubmission
{
    public Guid Id { get; set; }
    public string SCode { get; set; } = "";
    public long Hmy { get; set; }
    public string TCode { get; set; } = "";
    public string LegalEntityName { get; set; } = "";
    public string TinCiphertext { get; set; } = "";
    public string? TrnCiphertext { get; set; }
    public string CustomerType { get; set; } = "";
    public bool? IsVatRegistered { get; set; }
    public string TradeLicenseNumber { get; set; } = "";
    public string TradeLicenseIssuingAuthority { get; set; } = "";
    public string RegisteredAddressLine1 { get; set; } = "";
    public string City { get; set; } = "";
    public string Emirate { get; set; } = "";
    public string CountryCode { get; set; } = "";
    public string EInvoicingWave { get; set; } = "";
    public bool IsFreeZoneEntity { get; set; }
    public SubmissionStatus Status { get; set; }
    public DateTimeOffset SubmittedAtUtc { get; set; }
    public DateTimeOffset? ApprovedAtUtc { get; set; }
    public string? ApprovedBy { get; set; }
}

public sealed class SubmissionDocument
{
    public Guid Id { get; set; }
    public Guid SubmissionId { get; set; }
    public string Kind { get; set; } = "";
    public string ContentType { get; set; } = "";
    public string Extension { get; set; } = "";
    public byte[] Content { get; set; } = [];
    public DateTimeOffset UploadedAtUtc { get; set; }
}

public sealed class StagedCustomerDocument
{
    public Guid Id { get; set; }
    public long Hmy { get; set; }
    public string TCode { get; set; } = "";
    public string Kind { get; set; } = "";
    public int Ordinal { get; set; }
    public string ContentType { get; set; } = "";
    public string Extension { get; set; } = "";
    public string FileName { get; set; } = "";
    public byte[] Content { get; set; } = [];
    public DateTimeOffset UploadedAtUtc { get; set; }
}

public enum SubmissionStatus { PendingReview, Approved }

public sealed record ResidentLoginRequest(string? SCode, string? Hmy);
public sealed record TCodeLoginRequest(string? TCode, string? Password);
public sealed record CustomerLookupRequest(string? TCode);
public sealed record ExtractionRequest(bool? IsVatRegistered);
public sealed record ResidentSubmissionRequest(
    string? LegalEntityName,
    string? Tin,
    string? Trn,
    string? CustomerType,
    bool? IsVatRegistered,
    string? TradeLicenseNumber,
    string? TradeLicenseIssuingAuthority,
    string? RegisteredAddressLine1,
    string? City,
    string? Emirate,
    string? CountryCode,
    string? EInvoicingWave,
    bool? IsFreeZoneEntity);
