/*
Local static authentication does not use this file. Yardi mode calls the stored
procedure below. It returns only a boolean and reads a narrow normalized view.

    dbo.ResidentLoginDirectory
      SCode    nvarchar(100) -- resident code sent in the notification
      Hmy      nvarchar(512) -- exact text form of the confirmed resident key
      IsActive bit

Map the source only after confirming the Yardi product/version, Resident table
schema, HMY data type, and canonical text conversion. This is a mapping contract,
not an assertion about a Yardi API or schema. Do not expose other resident columns.
Grant the application database user EXECUTE on the procedure only; do not grant
SELECT on the view or source tables.

Illustrative templates below are intentionally non-executable until each
placeholder has been replaced using the confirmed source schema:

CREATE VIEW dbo.ResidentLoginDirectory AS
SELECT
    CAST(<resident-scode-expression> AS nvarchar(100)) AS SCode,
    CAST(<resident-hmy-expression> AS nvarchar(512)) AS Hmy,
    CAST(<resident-active-expression> AS bit) AS IsActive
FROM <confirmed-resident-source>;

CREATE PROCEDURE dbo.VerifyResidentCredential
    @SCode nvarchar(100),
    @Hmy nvarchar(512)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(CASE WHEN EXISTS
    (
        SELECT 1 FROM dbo.ResidentLoginDirectory
        WHERE SCode = @SCode AND Hmy = @Hmy AND IsActive = 1
    ) THEN 1 ELSE 0 END AS bit) AS IsValid;
END;

GRANT EXECUTE ON OBJECT::dbo.VerifyResidentCredential TO [<application-database-user>];
*/
