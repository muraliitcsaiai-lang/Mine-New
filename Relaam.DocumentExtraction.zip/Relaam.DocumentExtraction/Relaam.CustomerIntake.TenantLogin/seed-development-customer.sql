USE [CustomerMasterData];
GO

-- Development-only account requested for flow testing. Do not run this seed in production.
IF NOT EXISTS (SELECT 1 FROM dbo.YardiCustomers WHERE Hmy = 100000 AND TCode = N't000000')
BEGIN
    INSERT dbo.YardiCustomers (Hmy, TCode, Name, DtCreated, IsSubmitted, DtUpdated, IsExpired)
    VALUES (100000, N't000000', N'Test Customer', SYSUTCDATETIME(), 0, SYSUTCDATETIME(), 0);
END;
GO
