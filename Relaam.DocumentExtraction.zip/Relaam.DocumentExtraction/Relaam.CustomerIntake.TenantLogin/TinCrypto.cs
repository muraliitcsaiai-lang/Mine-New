using System.Security.Cryptography;

namespace Relaam.CustomerIntake.TenantLogin;

public sealed class TinCrypto
{
    private readonly string _activeKeyId;
    private readonly IReadOnlyDictionary<string, byte[]> _keys;

    public TinCrypto(IConfiguration configuration)
    {
        _activeKeyId = configuration["TinEncryption:ActiveKeyId"]
            ?? throw new InvalidOperationException("TinEncryption:ActiveKeyId is required.");
        if (_activeKeyId.Length is < 1 or > 32 || _activeKeyId.Contains('.'))
            throw new InvalidOperationException("TinEncryption:ActiveKeyId must be 1-32 characters and contain no periods.");

        var keys = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        foreach (var item in configuration.GetSection("TinEncryption:Keys").GetChildren())
        {
            var key = Convert.FromBase64String(item.Value ?? "");
            if (key.Length != 32) throw new InvalidOperationException($"TIN encryption key '{item.Key}' must be 32 bytes.");
            keys.Add(item.Key, key);
        }
        if (!keys.ContainsKey(_activeKeyId)) throw new InvalidOperationException("The active TIN encryption key is not configured.");
        _keys = keys;
    }

    public string Protect(string value)
    {
        var nonce = RandomNumberGenerator.GetBytes(12);
        var plaintext = System.Text.Encoding.UTF8.GetBytes(value);
        var ciphertext = new byte[plaintext.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(_keys[_activeKeyId], tag.Length);
        aes.Encrypt(nonce, plaintext, ciphertext, tag);
        return string.Join('.', _activeKeyId, Convert.ToBase64String(nonce), Convert.ToBase64String(ciphertext), Convert.ToBase64String(tag));
    }

    public string Unprotect(string protectedValue)
    {
        var parts = protectedValue.Split('.');
        if (parts.Length != 4 || !_keys.TryGetValue(parts[0], out var key))
            throw new CryptographicException("Stored TIN cannot be decrypted with the configured key ring.");
        var nonce = Convert.FromBase64String(parts[1]);
        var ciphertext = Convert.FromBase64String(parts[2]);
        var tag = Convert.FromBase64String(parts[3]);
        var plaintext = new byte[ciphertext.Length];
        using var aes = new AesGcm(key, tag.Length);
        aes.Decrypt(nonce, ciphertext, tag, plaintext);
        return System.Text.Encoding.UTF8.GetString(plaintext);
    }

    public byte[] ProtectBytes(byte[] plaintext)
    {
        var keyId = System.Text.Encoding.UTF8.GetBytes(_activeKeyId);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var ciphertext = new byte[plaintext.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(_keys[_activeKeyId], tag.Length);
        aes.Encrypt(nonce, plaintext, ciphertext, tag);
        var packed = new byte[1 + keyId.Length + nonce.Length + tag.Length + ciphertext.Length];
        packed[0] = checked((byte)keyId.Length);
        keyId.CopyTo(packed, 1);
        nonce.CopyTo(packed, 1 + keyId.Length);
        tag.CopyTo(packed, 1 + keyId.Length + nonce.Length);
        ciphertext.CopyTo(packed, 1 + keyId.Length + nonce.Length + tag.Length);
        return packed;
    }

    public byte[] UnprotectBytes(byte[] protectedValue)
    {
        if (protectedValue.Length < 1) throw new CryptographicException("Stored document cannot be decrypted.");
        var keyIdLength = protectedValue[0];
        var headerLength = 1 + keyIdLength + 12 + 16;
        if (keyIdLength is < 1 or > 32 || protectedValue.Length < headerLength)
            throw new CryptographicException("Stored document cannot be decrypted.");
        var keyId = System.Text.Encoding.UTF8.GetString(protectedValue, 1, keyIdLength);
        if (!_keys.TryGetValue(keyId, out var key)) throw new CryptographicException("Stored document encryption key is unavailable.");
        var nonce = protectedValue.AsSpan(1 + keyIdLength, 12);
        var tag = protectedValue.AsSpan(1 + keyIdLength + 12, 16);
        var ciphertext = protectedValue.AsSpan(headerLength);
        var plaintext = new byte[ciphertext.Length];
        using var aes = new AesGcm(key, tag.Length);
        aes.Decrypt(nonce, ciphertext, tag, plaintext);
        return plaintext;
    }
}
