USE [CustomerMasterData];
GO

CREATE TABLE dbo.YardiCustomers
(
    Hmy bigint NOT NULL,
    TCode nvarchar(100) NOT NULL,
    Name nvarchar(200) NOT NULL,
    DtCreated datetimeoffset NOT NULL CONSTRAINT DF_YardiCustomers_DtCreated DEFAULT SYSUTCDATETIME(),
    IsSubmitted bit NOT NULL CONSTRAINT DF_YardiCustomers_IsSubmitted DEFAULT 0,
    DtUpdated datetimeoffset NOT NULL CONSTRAINT DF_YardiCustomers_DtUpdated DEFAULT SYSUTCDATETIME(),
    IsExpired bit NOT NULL CONSTRAINT DF_YardiCustomers_IsExpired DEFAULT 0,
    CONSTRAINT PK_YardiCustomers PRIMARY KEY (Hmy, TCode),
    CONSTRAINT UQ_YardiCustomers_TCode UNIQUE (TCode)
);
GO

CREATE OR ALTER TRIGGER dbo.TR_YardiCustomers_SetDtUpdated
ON dbo.YardiCustomers
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF TRIGGER_NESTLEVEL() > 1 RETURN;
    UPDATE customer
       SET DtUpdated = SYSUTCDATETIME()
    FROM dbo.YardiCustomers AS customer
    INNER JOIN inserted AS updated
        ON updated.Hmy = customer.Hmy AND updated.TCode = customer.TCode;
END;
GO

CREATE TABLE dbo.CustomerSessions
(
    Id uniqueidentifier NOT NULL CONSTRAINT PK_CustomerSessions PRIMARY KEY,
    TokenHash nvarchar(64) NOT NULL,
    SCode nvarchar(100) NOT NULL,
    Hmy bigint NOT NULL,
    TCode nvarchar(100) NOT NULL,
    CreatedAtUtc datetimeoffset NOT NULL,
    ExpiresAtUtc datetimeoffset NOT NULL,
    RevokedAtUtc datetimeoffset NULL,
    CONSTRAINT FK_CustomerSessions_YardiCustomers FOREIGN KEY (Hmy, TCode) REFERENCES dbo.YardiCustomers(Hmy, TCode) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IX_CustomerSessions_TokenHash ON dbo.CustomerSessions(TokenHash);
CREATE INDEX IX_CustomerSessions_TCode_ExpiresAtUtc ON dbo.CustomerSessions(TCode, ExpiresAtUtc);

CREATE TABLE dbo.CustomerIntakeRecords
(
    Id uniqueidentifier NOT NULL CONSTRAINT PK_CustomerIntakeRecords PRIMARY KEY,
    SCode nvarchar(100) NOT NULL,
    Hmy bigint NOT NULL,
    TCode nvarchar(100) NOT NULL,
    LegalEntityName nvarchar(200) NOT NULL,
    TinCiphertext nvarchar(300) NOT NULL,
    TrnCiphertext nvarchar(300) NULL,
    CustomerType nvarchar(30) NOT NULL,
    IsVatRegistered bit NULL,
    TradeLicenseNumber nvarchar(300) NOT NULL,
    TradeLicenseIssuingAuthority nvarchar(200) NOT NULL,
    RegisteredAddressLine1 nvarchar(300) NOT NULL,
    City nvarchar(100) NOT NULL,
    Emirate nvarchar(100) NOT NULL,
    CountryCode nvarchar(2) NOT NULL,
    EInvoicingWave nvarchar(50) NOT NULL,
    IsFreeZoneEntity bit NOT NULL,
    Status int NOT NULL,
    SubmittedAtUtc datetimeoffset NOT NULL,
    ApprovedAtUtc datetimeoffset NULL,
    ApprovedBy nvarchar(100) NULL,
    CONSTRAINT FK_CustomerIntakeRecords_YardiCustomers FOREIGN KEY (Hmy, TCode) REFERENCES dbo.YardiCustomers(Hmy, TCode),
    CONSTRAINT UQ_CustomerIntakeRecords_TCode UNIQUE (TCode)
);
CREATE UNIQUE INDEX IX_CustomerIntakeRecords_SCode ON dbo.CustomerIntakeRecords(SCode);

CREATE TABLE dbo.StagedCustomerDocuments
(
    Id uniqueidentifier NOT NULL CONSTRAINT PK_StagedCustomerDocuments PRIMARY KEY,
    Hmy bigint NOT NULL,
    TCode nvarchar(100) NOT NULL,
    Kind nvarchar(40) NOT NULL,
    Ordinal int NOT NULL,
    ContentType nvarchar(50) NOT NULL,
    Extension nvarchar(5) NOT NULL,
    FileName nvarchar(180) NOT NULL,
    Content varbinary(max) NOT NULL,
    UploadedAtUtc datetimeoffset NOT NULL,
    CONSTRAINT FK_StagedCustomerDocuments_YardiCustomers FOREIGN KEY (Hmy, TCode) REFERENCES dbo.YardiCustomers(Hmy, TCode) ON DELETE CASCADE,
    CONSTRAINT UQ_StagedCustomerDocuments_Customer_Kind_Ordinal UNIQUE (Hmy, TCode, Kind, Ordinal)
);

CREATE TABLE dbo.SubmissionDocuments
(
    Id uniqueidentifier NOT NULL CONSTRAINT PK_SubmissionDocuments PRIMARY KEY,
    SubmissionId uniqueidentifier NOT NULL,
    Kind nvarchar(40) NOT NULL,
    ContentType nvarchar(50) NOT NULL,
    Extension nvarchar(5) NOT NULL,
    Content varbinary(max) NOT NULL,
    UploadedAtUtc datetimeoffset NOT NULL,
    CONSTRAINT FK_SubmissionDocuments_Submissions FOREIGN KEY (SubmissionId)
        REFERENCES dbo.CustomerIntakeRecords(Id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IX_SubmissionDocuments_SubmissionId_Kind ON dbo.SubmissionDocuments(SubmissionId, Kind);
