using System.Globalization;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Renci.SshNet;

namespace Relaam.CustomerIntake.TenantLogin;

public sealed class YardiCustomerSyncService(HttpClient client, IConfiguration configuration)
{
    public async Task<int> SyncAsync(IntakeDbContext db, CancellationToken cancellationToken)
    {
        var prefix = "Yardi:Api:";
        if (!bool.TryParse(configuration[prefix + "Enabled"], out var enabled) || !enabled)
            throw new InvalidOperationException("Yardi customer sync is disabled in configuration.");
        var endpoint = configuration[prefix + "Url"];
        var username = configuration[prefix + "Username"];
        var password = configuration[prefix + "Password"];
        var viewName = configuration[prefix + "ViewName"];
        if (!Uri.TryCreate(endpoint, UriKind.Absolute, out var endpointUri) || endpointUri.Scheme != Uri.UriSchemeHttps ||
            string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(viewName))
            throw new InvalidOperationException("Configure the HTTPS Yardi endpoint, credentials, and view name.");

        using var request = new HttpRequestMessage(HttpMethod.Post, endpointUri);
        request.Headers.Authorization = new AuthenticationHeaderValue("Basic",
            Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}")));
        request.Content = JsonContent.Create(new { sViewName = viewName });
        using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"Yardi customer export returned HTTP {(int)response.StatusCode}.");

        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        using var json = await JsonDocument.ParseAsync(stream, new JsonDocumentOptions { MaxDepth = 32 }, cancellationToken);
        var hmyField = configuration[prefix + "HmyField"] ?? "hmy";
        var tcodeField = configuration[prefix + "TcodeField"] ?? "tcode";
        var nameField = configuration[prefix + "NameField"] ?? "name";
        var rows = FindRows(json.RootElement, hmyField, tcodeField, nameField);
        if (rows is null) throw new InvalidDataException("Yardi returned JSON without a recognizable customer row array.");

        var changed = 0;
        var now = DateTimeOffset.UtcNow;
        var seenTcodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var seenKeys = new HashSet<(long Hmy, string TCode)>();
        var inserted = new Dictionary<(long Hmy, string TCode), YardiCustomer>();
        await using var transaction = await db.Database.BeginTransactionAsync(cancellationToken);
        foreach (var row in rows.Value.EnumerateArray())
        {
            if (!TryGetScalar(row, hmyField, out var hmyText) || !long.TryParse(hmyText, NumberStyles.None, CultureInfo.InvariantCulture, out var hmy) || hmy <= 0 ||
                !TryGetScalar(row, tcodeField, out var tcode) || string.IsNullOrWhiteSpace(tcode) || tcode.Length > 100 ||
                !TryGetScalar(row, nameField, out var name) || string.IsNullOrWhiteSpace(name) || name.Length > 200)
                continue;

            tcode = tcode.Trim();
            name = name.Trim();
            if (!seenKeys.Add((hmy, tcode)) || !seenTcodes.Add(tcode))
                throw new InvalidDataException("Yardi returned duplicate customer keys.");
            var key = (hmy, tcode);
            var customer = inserted.GetValueOrDefault(key)
                ?? await db.YardiCustomers.SingleOrDefaultAsync(item => item.Hmy == hmy && item.TCode == tcode, cancellationToken);
            if (customer is null)
            {
                if (await db.YardiCustomers.AnyAsync(item => item.TCode == tcode, cancellationToken))
                    throw new InvalidDataException("Yardi returned a tcode already assigned to a different hmy.");
                customer = new YardiCustomer
                {
                    Hmy = hmy, TCode = tcode, Name = name, DtCreated = now,
                    DtUpdated = now, IsSubmitted = false, IsExpired = false
                };
                db.YardiCustomers.Add(customer);
                inserted.Add(key, customer);
            }
            else
            {
                if (!string.Equals(customer.TCode, tcode, StringComparison.Ordinal))
                    throw new InvalidDataException("Yardi changed the tcode value for an existing customer key.");
                customer.Name = name;
                customer.DtUpdated = now;
            }
            changed++;
        }
        await db.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return changed;
    }

    private static JsonElement? FindRows(JsonElement value, string hmyField, string tcodeField, string nameField)
    {
        if (value.ValueKind == JsonValueKind.Array)
        {
            if (value.EnumerateArray().Any(row => row.ValueKind == JsonValueKind.Object &&
                HasProperty(row, hmyField) && HasProperty(row, tcodeField) && HasProperty(row, nameField))) return value;
            foreach (var child in value.EnumerateArray())
            {
                var nested = FindRows(child, hmyField, tcodeField, nameField);
                if (nested.HasValue) return nested;
            }
        }
        else if (value.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in value.EnumerateObject())
            {
                var nested = FindRows(property.Value, hmyField, tcodeField, nameField);
                if (nested.HasValue) return nested;
            }
        }
        return null;
    }

    private static bool HasProperty(JsonElement value, string name) =>
        value.EnumerateObject().Any(property => property.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

    private static bool TryGetScalar(JsonElement value, string name, out string result)
    {
        result = "";
        if (value.ValueKind != JsonValueKind.Object) return false;
        foreach (var property in value.EnumerateObject())
        {
            if (!property.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) continue;
            if (property.Value.ValueKind is JsonValueKind.String or JsonValueKind.Number)
                result = property.Value.ToString();
            return result.Length > 0;
        }
        return false;
    }
}

public interface IYardiDocumentTransfer
{
    bool Enabled { get; }
    Task UploadAsync(YardiCustomer customer, string kind, int ordinal, string extension, byte[] content, CancellationToken cancellationToken);
}

public sealed class YardiSftpDocumentTransfer(IConfiguration configuration) : IYardiDocumentTransfer
{
    public bool Enabled => bool.TryParse(configuration["Yardi:Sftp:Enabled"], out var enabled) && enabled;

    public Task UploadAsync(YardiCustomer customer, string kind, int ordinal, string extension, byte[] content, CancellationToken cancellationToken)
    {
        if (!Enabled) return Task.CompletedTask;
        var host = configuration["Yardi:Sftp:Host"];
        var username = configuration["Yardi:Sftp:Username"];
        var password = configuration["Yardi:Sftp:Password"];
        var keyPath = configuration["Yardi:Sftp:PrivateKeyPath"];
        var passphrase = configuration["Yardi:Sftp:PrivateKeyPassphrase"];
        var hostKey = configuration["Yardi:Sftp:HostKeySha256"];
        var remoteRoot = configuration["Yardi:Sftp:RemoteDirectory"];
        if (string.IsNullOrWhiteSpace(host) || string.IsNullOrWhiteSpace(username) ||
            (string.IsNullOrWhiteSpace(password) && string.IsNullOrWhiteSpace(keyPath)) ||
            string.IsNullOrWhiteSpace(hostKey) || string.IsNullOrWhiteSpace(remoteRoot) ||
            !int.TryParse(configuration["Yardi:Sftp:Port"], out var port) || port is < 1 or > 65535)
            throw new InvalidOperationException("SFTP is enabled but its host, port, user, credentials, pinned host key, or destination is missing.");

        var safeTcode = Regex.Replace(customer.TCode, "[^A-Za-z0-9_-]", "_");
        var safeKind = Regex.Replace(kind, "[^A-Za-z0-9_-]", "_");
        var folder = $"{remoteRoot.TrimEnd('/')}/hmy-{customer.Hmy}/{safeTcode}";
        var destination = $"{folder}/{safeKind}-{ordinal}{extension.ToLowerInvariant()}";

        return Task.Run(() =>
        {
            var auth = new List<AuthenticationMethod>();
            if (!string.IsNullOrWhiteSpace(password)) auth.Add(new PasswordAuthenticationMethod(username, password));
            if (!string.IsNullOrWhiteSpace(keyPath)) auth.Add(new PrivateKeyAuthenticationMethod(username, new PrivateKeyFile(keyPath, passphrase)));
            var connection = new Renci.SshNet.ConnectionInfo(host, port, username, auth.ToArray()) { Timeout = TimeSpan.FromSeconds(30) };
            using var client = new SftpClient(connection);
            client.HostKeyReceived += (_, eventArgs) => eventArgs.CanTrust = MatchesFingerprint(eventArgs.HostKey, hostKey);
            client.Connect();
            EnsureDirectory(client, folder);
            using var input = new MemoryStream(content, writable: false);
            client.UploadFile(input, destination, canOverride: true);
            client.Disconnect();
        }, cancellationToken);
    }

    private static bool MatchesFingerprint(byte[] hostKey, string configured)
    {
        var expected = configured.Trim();
        var actualHash = SHA256.HashData(hostKey);
        if (expected.StartsWith("SHA256:", StringComparison.OrdinalIgnoreCase))
        {
            var actual = "SHA256:" + Convert.ToBase64String(actualHash).TrimEnd('=');
            return CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(actual), Encoding.ASCII.GetBytes(expected));
        }
        try
        {
            var expectedBytes = Convert.FromHexString(expected.Replace(":", ""));
            return expectedBytes.Length == actualHash.Length && CryptographicOperations.FixedTimeEquals(actualHash, expectedBytes);
        }
        catch (FormatException) { return false; }
    }

    private static void EnsureDirectory(SftpClient client, string path)
    {
        var current = path.StartsWith('/') ? "/" : "";
        foreach (var segment in path.Split('/', StringSplitOptions.RemoveEmptyEntries))
        {
            current = current.Length == 0 || current == "/" ? current + segment : current + "/" + segment;
            if (!client.Exists(current)) client.CreateDirectory(current);
        }
    }
}
