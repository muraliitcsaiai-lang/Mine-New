# Relaam customer information portal

This ASP.NET Core application stores Yardi customer keys and customer-submitted e-invoicing information in the CustomerMasterData SQL Server database. Customer links use a tcode query parameter. The page removes it from browser history immediately, displays the matching Yardi name as a read-only username, and compares the SMS password with the customer hmy. After sign-in, an HttpOnly, Secure, SameSite cookie keeps the 12-hour session across refreshes.

## Development

The Development configuration targets the local SQL Server LocalDB instance shown in SSMS: (localdb)\ProjectModels, database CustomerMasterData. Schema auto-creation is enabled only in Development. On an empty database the app inserts a development customer named Test Customer with tcode t000000 and hmy 100000. To test, open the HTTPS app, use a URL ending in /resident-login.html?tcode=t000000, and enter 100000 as the password. Do not use this test row outside Development or isolated UAT.

Prerequisites are .NET 10, SQL Server LocalDB, Tesseract 5 with English data, and Poppler. Paths for Tesseract and pdftoppm are set in appsettings.Development.json. Start from the project folder with dotnet run. The app requires a valid local TIN encryption key and staff key from Development configuration.

## Database

The database contains YardiCustomers, CustomerSessions, CustomerIntakeRecords, StagedCustomerDocuments, and SubmissionDocuments. CustomerIntakeRecords and documents reference YardiCustomers by the composite hmy/tcode key. The supplied Yardi sample repeats hmy for different tcodes, so hmy alone cannot be the primary key; tcode is unique.

For a new production database, create CustomerMasterData, review schema.sql, and run it with a DBA-approved deployment identity before starting the application. Do not grant the web application schema-creation rights in production. The Development-only sample row is also available in seed-development-customer.sql; do not run that script against production.

## Yardi customer sync

The staff-protected endpoint POST /api/admin/yardi/sync calls the configured HTTPS Yardi export endpoint using Basic authentication and sends the configured sViewName. It supports a top-level array and common nested JSON arrays, and maps hmy, tcode, and name case-insensitively. The shown sample with a capitalized Name property is supported. Duplicate (hmy, tcode) rows or duplicate tcodes are rejected; the sync does not log response values or credentials.

Configure the server environment or secret provider with Yardi__Api__Enabled=true, Yardi__Api__Username, Yardi__Api__Password, and optionally Yardi__Api__ViewName, Yardi__Api__Url, Yardi__Api__HmyField, Yardi__Api__TcodeField, and Yardi__Api__NameField. The endpoint is preconfigured in appsettings.json and the view defaults to ABC. The password must not be committed to JSON or sent from the browser. Call the endpoint with X-Staff-Key using the configured Staff key. Sync is disabled until explicitly enabled.

## Document upload and submission

Customers must upload the FTA TIN evidence, a TRN certificate when VAT registered, and one to three trade licenses. Only PDF, JPG/JPEG, and PNG files up to 5 MB are accepted. Files are staged encrypted in SQL Server when selected; the View link is scoped to the signed-in customer. The Extract button stays disabled until the required document groups are staged. Extraction reads the staged documents. On submit, the customer record is marked submitted and the saved form and documents are shown read-only on future visits.

SFTP is implemented with SSH.NET and is disabled by default. To enable it, configure Yardi__Sftp__Enabled=true, Host, Port, Username, Password or PrivateKeyPath, PrivateKeyPassphrase when needed, HostKeySha256, and RemoteDirectory. Use a pinned SHA-256 host key and server-side secrets. Uploaded files are placed under the configured remote directory in hmy/tcode folders. The app currently does not delete remote SFTP files when staged documents are replaced or removed; confirm the remote retention and cleanup process with the Yardi SFTP owner before enabling production uploads.

## Security and deployment notes

The hmy-as-password behavior is implemented as requested, with rate-limited login attempts and constant-time comparison. An hmy is a database identifier, not a strong secret; before using real customers, replace this with an expiring, single-use SMS code or another approved authentication factor. Use HTTPS, keep API keys, SQL secrets, SFTP credentials, host-key fingerprints, staff keys, and encryption keys in a managed secret store, and set a retention/deletion schedule for customer documents. Do not log customer values or upload content.

The app uses the CodeIntegrity/App Control policy on managed Windows devices. Locally built binaries may require a company-approved signing or development rule before Windows will load them. Do not disable the policy to run the app.

The reusable OCR library is in Relaam.DocumentExtraction. The Tesseract provider processes files locally; the OpenAI provider sends selected files to OpenAI for processing and must be enabled only under the company-approved data flow and account controls.
