using Microsoft.EntityFrameworkCore;

namespace Relaam.CustomerIntake.TenantLogin;

/// <summary>Calls only the resident credential-verification procedure documented in ResidentLoginDirectory.sql.</summary>
public sealed class CustomerDirectoryContext(DbContextOptions<CustomerDirectoryContext> options) : DbContext(options)
{
    public DbSet<ResidentLoginResult> VerificationResults => Set<ResidentLoginResult>();

    protected override void OnModelCreating(ModelBuilder modelBuilder) =>
        modelBuilder.Entity<ResidentLoginResult>().HasNoKey();
}

public sealed class ResidentLoginResult
{
    public bool IsValid { get; set; }
}
