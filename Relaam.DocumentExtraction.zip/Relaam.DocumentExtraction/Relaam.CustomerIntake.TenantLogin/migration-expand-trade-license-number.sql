/* Apply once to an existing intake database before deploying multiple-license support. */
ALTER TABLE dbo.Submissions
    ALTER COLUMN TradeLicenseNumber nvarchar(300) NOT NULL;
GO
