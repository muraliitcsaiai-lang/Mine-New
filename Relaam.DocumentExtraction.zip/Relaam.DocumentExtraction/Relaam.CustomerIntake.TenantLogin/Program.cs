using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Relaam.DocumentExtraction;
using Relaam.CustomerIntake.TenantLogin;
using Serilog;
using Serilog.Context;

public partial class Program
{
    private const string CustomerSessionCookie = "__Host-RelaamCustomerSession";

    private static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        const long maxUploadRequestBytes = 32 * 1024 * 1024;
        builder.WebHost.ConfigureKestrel(options => options.Limits.MaxRequestBodySize = maxUploadRequestBytes);
        builder.Host.UseSerilog((context, services, configuration) => configuration
            .ReadFrom.Configuration(context.Configuration)
            .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {Level:u3}] {Message:lj} {Properties:j}{NewLine}{Exception}")
            .Enrich.FromLogContext()
            .Enrich.WithProperty("Application", "Relaam.CustomerIntake.TenantLogin"));
        builder.Services.AddHttpClient("OpenAI", client => client.Timeout = TimeSpan.FromSeconds(60));
        builder.Services.AddHttpClient<YardiCustomerSyncService>(client => client.Timeout = TimeSpan.FromSeconds(60));
        builder.Services.AddSingleton<IYardiDocumentTransfer, YardiSftpDocumentTransfer>();
        builder.Services.AddSingleton<IDocumentExtractor>(services =>
        {
            var configuration = services.GetRequiredService<IConfiguration>();
            var provider = configuration["DocumentExtraction:Provider"] ?? "OpenAI";
            if (provider.Equals("Tesseract", StringComparison.OrdinalIgnoreCase))
            {
                return new TesseractDocumentExtractor(
                    configuration["DocumentExtraction:TesseractExecutable"] ?? "tesseract",
                    configuration["DocumentExtraction:PdfToImageExecutable"] ?? "pdftoppm",
                    configuration["DocumentExtraction:TessdataDirectory"],
                    configuration["DocumentExtraction:Languages"] ?? "eng");
            }

        if (provider.Equals("Indra", StringComparison.OrdinalIgnoreCase))
        {
           return new IndraDocumentExtractor(
            modelDirectory:null, //builder.Configuration["DocumentExtraction:ModelDirectory"],
            threads: builder.Configuration.GetValue("DocumentExtraction:Threads", 4));
           }

            if (provider.Equals("OpenAI", StringComparison.OrdinalIgnoreCase))
            {
                var httpClientFactory = services.GetRequiredService<IHttpClientFactory>();
                var options = new OpenAiDocumentExtractionOptions(
                    configuration["OpenAI:ApiKey"], configuration["OpenAI:Model"] ?? "gpt-5.4-mini");
                return new OpenAiDocumentExtractor(httpClientFactory.CreateClient("OpenAI"), options);
            }

            throw new InvalidOperationException("DocumentExtraction:Provider must be Tesseract, Indra, or OpenAI.");

        });

      
    

        var storageProvider = builder.Configuration["Storage:Provider"] ?? "";
        if (storageProvider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
        {
            if (!builder.Environment.IsDevelopment())
                throw new InvalidOperationException("SQLite storage is enabled only in Development.");
            var sqliteConnection = builder.Configuration.GetConnectionString("CustomerIntake")
                ?? throw new InvalidOperationException("ConnectionStrings:CustomerIntake is required.");
            builder.Services.AddDbContext<IntakeDbContext>(options => options.UseSqlite(sqliteConnection));
        }
        else if (storageProvider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
        {
            var sqlConnection = builder.Configuration.GetConnectionString("CustomerIntake")
                ?? throw new InvalidOperationException("ConnectionStrings:CustomerIntake is required for SQL Server storage.");
            builder.Services.AddDbContext<IntakeDbContext>(options => options
                .UseSqlServer(sqlConnection, sql => sql.CommandTimeout(5))
                .EnableSensitiveDataLogging(false));
        }
        else
        {
            throw new InvalidOperationException("Storage:Provider must be Sqlite or SqlServer.");
        }

        var staffApiKey = builder.Configuration["Staff:ApiKey"];
        if (string.IsNullOrWhiteSpace(staffApiKey) || staffApiKey.Length < 32)
            throw new InvalidOperationException("Staff:ApiKey must be configured with at least 32 characters.");

        builder.Services.AddSingleton(new TinCrypto(builder.Configuration));
        builder.Services.AddRateLimiter(options =>
        {
            options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            options.AddPolicy("customer-login", context => RateLimitPartition.GetFixedWindowLimiter(
                context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
                _ => new FixedWindowRateLimiterOptions
                {
                    PermitLimit = 5,
                    Window = TimeSpan.FromMinutes(1),
                    QueueLimit = 0,
                    AutoReplenishment = true
                }));
        });
        builder.Services.AddProblemDetails();

        var app = builder.Build();
        var documentExtractor = app.Services.GetRequiredService<IDocumentExtractor>();
        if (documentExtractor is TesseractDocumentExtractor localOcr)
            Log.Information("Local OCR tool availability checked. TesseractAvailable={TesseractAvailable} PdfRendererAvailable={PdfRendererAvailable}",
                localOcr.TesseractAvailable, localOcr.PdfRendererAvailable);
        if (!documentExtractor.IsConfigured)
            Log.Warning("Configured document extraction provider is unavailable. Provider={Provider}", builder.Configuration["DocumentExtraction:Provider"] ?? "OpenAI");
        if (app.Environment.IsDevelopment() && builder.Configuration.GetValue<bool>("Storage:AutoCreateSchema"))
        {
            await using var scope = app.Services.CreateAsyncScope();
            var db = scope.ServiceProvider.GetRequiredService<IntakeDbContext>();
            await db.Database.EnsureCreatedAsync();
            if (storageProvider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
                await EnsureSqliteSchemaAsync(db);
            if (!await db.YardiCustomers.AnyAsync())
            {
                var now = DateTimeOffset.UtcNow;
                db.YardiCustomers.Add(new YardiCustomer
                {
                    Hmy = 100000, TCode = "t000000", Name = "Test Customer",
                    DtCreated = now, DtUpdated = now, IsSubmitted = false, IsExpired = false
                });
                await db.SaveChangesAsync();
            }
        }

        app.UseExceptionHandler(handler => handler.Run(async context =>
        {
            var exception = context.Features.Get<IExceptionHandlerFeature>()?.Error;
            if (exception is not null)
                Log.Error(exception, "Unhandled request failure. RequestId={RequestId}", context.TraceIdentifier);
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            await context.Response.WriteAsJsonAsync(new { error = "The request could not be completed.", requestId = context.TraceIdentifier });
        }));
        app.UseSerilogRequestLogging(options =>
        {
            options.GetLevel = (context, _, exception) =>
                exception is not null || context.Response.StatusCode >= 500
                    ? Serilog.Events.LogEventLevel.Error
                    : context.Response.StatusCode >= 400
                        ? Serilog.Events.LogEventLevel.Warning
                        : Serilog.Events.LogEventLevel.Information;
            options.EnrichDiagnosticContext = (diagnosticContext, context) =>
                diagnosticContext.Set("RequestId", context.TraceIdentifier);
        });
        app.UseHsts();
        app.UseHttpsRedirection();
        app.Use(async (context, next) =>
        {
            context.Response.Headers["X-Request-ID"] = context.TraceIdentifier;
            context.Response.Headers["X-Content-Type-Options"] = "nosniff";
            context.Response.Headers["X-Frame-Options"] = "DENY";
            context.Response.Headers["Referrer-Policy"] = "no-referrer";
            context.Response.Headers["Cache-Control"] = "no-store";
            context.Response.Headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self' https://www.relaam.com; script-src 'self'; style-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
            using (LogContext.PushProperty("RequestId", context.TraceIdentifier)) await next();
        });
        app.UseRateLimiter();
        app.UseStaticFiles();

        app.MapGet("/health/live", () => Results.Ok(new { status = "ok" }));
        app.MapGet("/health/ready", async (IntakeDbContext db) =>
            await db.Database.CanConnectAsync()
                ? Results.Ok(new { status = "ready" })
                : Results.StatusCode(StatusCodes.Status503ServiceUnavailable));
        app.MapGet("/", () => Results.Redirect("/resident-login.html"));

        app.MapPost("/api/resident/customer/lookup", async (CustomerLookupRequest request, IntakeDbContext db, HttpContext http) =>
        {
            http.Response.Headers["Cache-Control"] = "no-store";
            if (string.IsNullOrWhiteSpace(request.TCode) || request.TCode.Length > 100) return Results.NotFound();
            var customer = await db.YardiCustomers.AsNoTracking().SingleOrDefaultAsync(item => item.TCode == request.TCode.Trim());
            return customer is null || customer.IsExpired
                ? Results.NotFound(new { error = "This customer link is invalid or expired." })
                : Results.Ok(new { tcode = customer.TCode, name = customer.Name, customerType = customer.CustomerType });
        }).RequireRateLimiting("customer-login");

        app.MapGet("/api/resident/me", async (HttpContext http, IntakeDbContext db, TinCrypto tinCrypto) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            var customer = await db.YardiCustomers.AsNoTracking()
                .SingleOrDefaultAsync(item => item.Hmy == session.Hmy && item.TCode == session.TCode);
            if (customer is null || customer.IsExpired) return Results.Unauthorized();
            var submission = customer.IsSubmitted
                ? await db.Submissions.AsNoTracking().SingleOrDefaultAsync(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode)
                : null;
            var docs = submission is null
                ? await db.StagedDocuments.AsNoTracking().Where(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode)
                    .OrderBy(item => item.Kind).ThenBy(item => item.Ordinal)
                    .Select(item => new { item.Id, item.Kind, item.FileName }).ToListAsync()
                : await db.Documents.AsNoTracking().Where(item => item.SubmissionId == submission.Id)
                    .Select(item => new { item.Id, item.Kind, FileName = item.Kind + item.Extension }).ToListAsync();
            var fields = submission is null ? null : new
            {
                customerType = submission.CustomerType,
                legalEntityName = submission.LegalEntityName,
                tin = tinCrypto.Unprotect(submission.TinCiphertext),
                trn = submission.TrnCiphertext is null ? null : tinCrypto.Unprotect(submission.TrnCiphertext),
                tradeLicenseNumber = submission.TradeLicenseNumber,
                tradeLicenseIssuingAuthority = submission.TradeLicenseIssuingAuthority,
                registeredAddressLine1 = submission.RegisteredAddressLine1,
                city = submission.City,
                emirate = submission.Emirate,
                countryCode = submission.CountryCode,
                eInvoicingWave = submission.EInvoicingWave,
                isVatRegistered = submission.IsVatRegistered,
                isFreeZoneEntity = submission.IsFreeZoneEntity
            };
            return Results.Ok(new { customerName = customer.Name, tcode = customer.TCode, customerType= customer.CustomerType, isSubmitted = customer.IsSubmitted, fields, documents = docs });
        });

        app.MapPost("/api/resident/login", async (TCodeLoginRequest request, IntakeDbContext db, HttpContext http) =>
        {
            http.Response.Headers["Cache-Control"] = "no-store";
            if (string.IsNullOrWhiteSpace(request.TCode) || request.TCode.Length > 100 ||
                string.IsNullOrWhiteSpace(request.Password) || request.Password.Length > 128)
                return Results.Unauthorized();

            var customer = await db.YardiCustomers.SingleOrDefaultAsync(item => item.TCode == request.TCode.Trim(), http.RequestAborted);
            var expected = customer is null ? "not-a-valid-customer" : customer.Hmy.ToString(System.Globalization.CultureInfo.InvariantCulture);
            var valid = customer is not null && !customer.IsExpired && SecretEquals(expected, request.Password);
            if (!valid)
            {
                Log.Warning("Resident sign-in failed. RequestId={RequestId}", http.TraceIdentifier);
                return Results.Unauthorized();
            }
            var authenticatedCustomer = customer!;

            var rawSessionToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
                .TrimEnd('=').Replace('+', '-').Replace('/', '_');
            var session = new CustomerSession
            {
                Id = Guid.NewGuid(),
                TokenHash = TokenHash(rawSessionToken),
                SCode = authenticatedCustomer.TCode,
                Hmy = authenticatedCustomer.Hmy,
                TCode = authenticatedCustomer.TCode,
                CreatedAtUtc = DateTimeOffset.UtcNow,
                ExpiresAtUtc = DateTimeOffset.UtcNow.AddHours(12)
            };
            db.CustomerSessions.Add(session);
            await db.SaveChangesAsync();
            Log.Information("Resident sign-in succeeded. SessionId={SessionId}", session.Id);
            http.Response.Cookies.Append(CustomerSessionCookie, rawSessionToken, new CookieOptions
            {
                HttpOnly = true, Secure = true, SameSite = SameSiteMode.Strict,
                Path = "/", MaxAge = TimeSpan.FromHours(12), IsEssential = true
            });
            return Results.Ok(new { customerName = authenticatedCustomer.Name, tcode = authenticatedCustomer.TCode });
        }).RequireRateLimiting("customer-login");

        app.MapPost("/api/resident/logout", async (HttpContext http, IntakeDbContext db) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is not null)
            {
                session.RevokedAtUtc = DateTimeOffset.UtcNow;
                await db.SaveChangesAsync();
            }
            http.Response.Cookies.Delete(CustomerSessionCookie, new CookieOptions { Secure = true, HttpOnly = true, SameSite = SameSiteMode.Strict, Path = "/" });
            return Results.NoContent();
        });

        app.MapPost("/api/admin/yardi/sync", async (HttpContext http, IntakeDbContext db, YardiCustomerSyncService sync) =>
        {
            if (!HasStaffKey(http, staffApiKey)) return Results.Unauthorized();
            try
            {
                var count = await sync.SyncAsync(db, http.RequestAborted);
                Log.Information("Yardi customer sync completed. CustomerCount={CustomerCount} RequestId={RequestId}", count, http.TraceIdentifier);
                return Results.Ok(new { importedOrUpdated = count });
            }
            catch (Exception exception) when (exception is HttpRequestException or InvalidOperationException or InvalidDataException or JsonException)
            {
                Log.Warning("Yardi customer sync failed. FailureType={FailureType} RequestId={RequestId}", exception.GetType().Name, http.TraceIdentifier);
                return Results.Json(new { error = "Yardi customer sync failed. Check server configuration and Yardi response mapping." }, statusCode: StatusCodes.Status502BadGateway);
            }
        }).RequireRateLimiting("customer-login");

        app.MapPost("/api/resident/documents/upload", async (HttpContext http, IntakeDbContext db, TinCrypto tinCrypto, IYardiDocumentTransfer transfer) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            var customer = await db.YardiCustomers.SingleOrDefaultAsync(item => item.Hmy == session.Hmy && item.TCode == session.TCode);
            if (customer is null || customer.IsExpired) return Results.Unauthorized();
            if (customer.IsSubmitted) return Results.Conflict(new { error = "This customer has already submitted the information." });
            if (!http.Request.HasFormContentType) return Results.BadRequest(new { error = "Upload documents using multipart form data." });

            IFormCollection form;
            try { form = await http.Request.ReadFormAsync(http.RequestAborted); }
            catch (InvalidDataException) { return Results.BadRequest(new { error = "The upload is invalid or exceeds the allowed size." }); }
            var kind = form["kind"].ToString();
            var acceptedKinds = new HashSet<string>(["ftaTinScreenshot", "trnCertificate", "tradeLicenseAttachment"], StringComparer.Ordinal);
            if (!acceptedKinds.Contains(kind) || form.Files.Count is < 1 or > 3 || (kind != "tradeLicenseAttachment" && form.Files.Count != 1))
                return Results.BadRequest(new { error = "Upload one tax document or one to three trade licenses." });

            var ready = new List<(IFormFile File, string ContentType, string Extension, byte[] Bytes)>();
            foreach (var file in form.Files)
            {
                if (!ValidateUpload(file, required: true, out var contentType, out var extension, out var error))
                    return Results.ValidationProblem(new Dictionary<string, string[]> { [kind] = [error] });
                await using var stream = new MemoryStream();
                await file.CopyToAsync(stream, http.RequestAborted);
                ready.Add((file, contentType, extension, stream.ToArray()));
            }

            try
            {
                for (var i = 0; i < ready.Count; i++)
                    await transfer.UploadAsync(customer, kind, i + 1, ready[i].Extension, ready[i].Bytes, http.RequestAborted);
            }
            catch (Exception exception) when (exception is InvalidOperationException or Renci.SshNet.Common.SshException or IOException)
            {
                Log.Warning("Customer document transfer failed. DocumentKind={DocumentKind} RequestId={RequestId}", kind, http.TraceIdentifier);
                return Results.Json(new { error = "The document could not be uploaded. Please retry or contact support." }, statusCode: StatusCodes.Status502BadGateway);
            }

            var previous = await db.StagedDocuments.Where(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode && item.Kind == kind).ToListAsync();
            db.StagedDocuments.RemoveRange(previous);
            for (var i = 0; i < ready.Count; i++)
            {
                var item = ready[i];
                db.StagedDocuments.Add(new StagedCustomerDocument
                {
                    Id = Guid.NewGuid(), Hmy = customer.Hmy, TCode = customer.TCode, Kind = kind,
                    Ordinal = i + 1, ContentType = item.ContentType, Extension = item.Extension,
                    FileName = Path.GetFileName(item.File.FileName)[..Math.Min(Path.GetFileName(item.File.FileName).Length, 180)],
                    Content = tinCrypto.ProtectBytes(item.Bytes), UploadedAtUtc = DateTimeOffset.UtcNow
                });
            }
            await db.SaveChangesAsync(http.RequestAborted);
            var saved = await db.StagedDocuments.AsNoTracking().Where(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode)
                .OrderBy(item => item.Kind).ThenBy(item => item.Ordinal)
                .Select(item => new { item.Id, item.Kind, item.Ordinal, item.FileName }).ToListAsync(http.RequestAborted);
            return Results.Ok(new { documents = saved, sftpEnabled = transfer.Enabled });
        }).RequireRateLimiting("customer-login");

        app.MapGet("/api/resident/documents/{id:guid}/view", async (Guid id, HttpContext http, IntakeDbContext db, TinCrypto tinCrypto) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            var staged = await db.StagedDocuments.AsNoTracking().SingleOrDefaultAsync(item => item.Id == id && item.Hmy == session.Hmy && item.TCode == session.TCode);
            if (staged is not null)
            {
                http.Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
                return Results.File(tinCrypto.UnprotectBytes(staged.Content), staged.ContentType, fileDownloadName: null, enableRangeProcessing: false);
            }
            var submitted = await db.Documents.AsNoTracking()
                .Join(db.Submissions.AsNoTracking(), document => document.SubmissionId, submission => submission.Id,
                    (document, submission) => new { document, submission })
                .Where(pair => pair.document.Id == id && pair.submission.Hmy == session.Hmy && pair.submission.TCode == session.TCode)
                .Select(pair => pair.document).SingleOrDefaultAsync();
            if (submitted is null) return Results.NotFound();
            http.Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
            return Results.File(tinCrypto.UnprotectBytes(submitted.Content), submitted.ContentType, fileDownloadName: null, enableRangeProcessing: false);
        });

        app.MapDelete("/api/resident/documents/{kind}", async (string kind, HttpContext http, IntakeDbContext db) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            if (kind is not ("ftaTinScreenshot" or "trnCertificate" or "tradeLicenseAttachment")) return Results.NotFound();
            var staged = await db.StagedDocuments.Where(item => item.Hmy == session.Hmy && item.TCode == session.TCode && item.Kind == kind).ToListAsync();
            db.StagedDocuments.RemoveRange(staged);
            await db.SaveChangesAsync(http.RequestAborted);
            return Results.NoContent();
        }).RequireRateLimiting("customer-login");

        app.MapPost("/api/resident/extract", async (HttpContext http, IntakeDbContext db, TinCrypto tinCrypto, IDocumentExtractor extractor) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            var customer = await db.YardiCustomers.AsNoTracking().SingleOrDefaultAsync(item => item.Hmy == session.Hmy && item.TCode == session.TCode);
            if (customer is null || customer.IsExpired) return Results.Unauthorized();
            if (customer.IsSubmitted) return Results.Conflict(new { error = "This customer has already submitted the information." });
            if (!extractor.IsConfigured)
            {
                Log.Warning("Document extraction is unavailable because the provider is not configured. RequestId={RequestId}", http.TraceIdentifier);
                return Results.Json(new { error = "Document reading is unavailable right now. You can enter the details manually." }, statusCode: StatusCodes.Status503ServiceUnavailable);
            }
            ExtractionRequest? extractionRequest;
            try { extractionRequest = await http.Request.ReadFromJsonAsync<ExtractionRequest>(cancellationToken: http.RequestAborted); }
            catch (JsonException) { return Results.BadRequest(new { error = "Choose whether the customer is VAT registered." }); }
            if (extractionRequest?.IsVatRegistered is null)
                return Results.BadRequest(new { error = "Choose whether the customer is VAT registered." });

            var staged = await db.StagedDocuments.AsNoTracking()
                .Where(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode)
                .OrderBy(item => item.Kind).ThenBy(item => item.Ordinal).ToListAsync(http.RequestAborted);
            var hasTinEvidence = staged.Any(item => item.Kind == "ftaTinScreenshot");
            var hasLicense = staged.Any(item => item.Kind == "tradeLicenseAttachment");
            var hasTrnCertificate = staged.Any(item => item.Kind == "trnCertificate");
            if (!hasTinEvidence || !hasLicense || (extractionRequest.IsVatRegistered == true && !hasTrnCertificate) ||
                (extractionRequest.IsVatRegistered == false && hasTrnCertificate))
            {
                return Results.BadRequest(new { error = "Upload every required document before extracting information." });
            }

            var uploads = staged.Select(item => new UploadedDocument(item.Kind, item.ContentType, item.Extension,
                tinCrypto.UnprotectBytes(item.Content))).ToArray();

            var extractionStartedAt = Stopwatch.GetTimestamp();
            Log.Information("Document extraction started. RequestId={RequestId} DocumentCount={DocumentCount} TotalBytes={TotalBytes} Model={Model}",
                http.TraceIdentifier, uploads.Length, uploads.Sum(upload => (long)upload.Content.Length), extractor.Model);
            try
            {
                var fields = await extractor.ExtractAsync(uploads, http.RequestAborted);
                http.Response.Headers["Cache-Control"] = "no-store";
                Log.Information("Document extraction completed. RequestId={RequestId} DurationMs={DurationMs}",
                    http.TraceIdentifier, Stopwatch.GetElapsedTime(extractionStartedAt).TotalMilliseconds);
                return Results.Ok(new { fields });
            }
            catch (DocumentExtractionException exception)
            {
                Log.Warning("Document extraction provider returned an error. StatusCode={StatusCode} RequestId={RequestId}", exception.StatusCode, http.TraceIdentifier);
                return Results.Json(new { error = "We could not extract details from these files. You can enter them manually." }, statusCode: StatusCodes.Status502BadGateway);
            }
            catch (HttpRequestException)
            {
                Log.Warning("Document extraction provider is unavailable. RequestId={RequestId}", http.TraceIdentifier);
                return Results.Json(new { error = "Document extraction is temporarily unavailable. You can enter the details manually." }, statusCode: StatusCodes.Status502BadGateway);
            }
            catch (TimeoutException exception)
            {
                Log.Warning("Document extraction provider timed out. TimeoutReason={TimeoutReason} RequestId={RequestId}",
                    exception.Message, http.TraceIdentifier);
                return Results.Json(new { error = "Document reading took too long. Please retry or enter the details manually." }, statusCode: StatusCodes.Status504GatewayTimeout);
            }
            catch (InvalidOperationException)
            {
                Log.Warning("Configured document extraction provider is not ready. Provider={Provider} RequestId={RequestId}",
                    builder.Configuration["DocumentExtraction:Provider"] ?? "OpenAI", http.TraceIdentifier);
                return Results.Json(new { error = "Document reading is not ready. Please retry later or enter the details manually." }, statusCode: StatusCodes.Status503ServiceUnavailable);
            }
            catch (OperationCanceledException) when (!http.RequestAborted.IsCancellationRequested)
            {
                Log.Warning("OpenAI document extraction timed out. RequestId={RequestId}", http.TraceIdentifier);
                return Results.Json(new { error = "Document extraction timed out. You can retry or enter the details manually." }, statusCode: StatusCodes.Status504GatewayTimeout);
            }
        }).RequireRateLimiting("customer-login");

        app.MapPost("/api/resident/submissions", async (HttpContext http, IntakeDbContext db, TinCrypto tinCrypto) =>
        {
            var session = await FindSessionAsync(http, db);
            if (session is null) return Results.Unauthorized();
            var customer = await db.YardiCustomers.SingleOrDefaultAsync(item => item.Hmy == session.Hmy && item.TCode == session.TCode);
            if (customer is null || customer.IsExpired) return Results.Unauthorized();
            if (customer.IsSubmitted) return Results.Conflict(new { error = "This customer has already submitted the information." });

            if (!http.Request.HasFormContentType)
                return Results.BadRequest(new { error = "Submit the form using multipart form data." });

            IFormCollection form;
            try { form = await http.Request.ReadFormAsync(http.RequestAborted); }
            catch (InvalidDataException) { return Results.BadRequest(new { error = "The upload request is invalid or exceeds the allowed size." }); }

            bool? ParseBoolean(string key) => bool.TryParse(form[key], out var value) ? value : null;
            var request = new ResidentSubmissionRequest(
                form["legalEntityName"], form["tin"], form["trn"], form["customerType"],
                ParseBoolean("isVatRegistered"), form["tradeLicenseNumber"],
                form["tradeLicenseIssuingAuthority"], form["registeredAddressLine1"], form["city"],
                form["emirate"], form["countryCode"], form["eInvoicingWave"], ParseBoolean("isFreeZoneEntity"));
            var errors = Validate(request);
            var stagedDocuments = await db.StagedDocuments.Where(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode)
                .OrderBy(item => item.Kind).ThenBy(item => item.Ordinal).ToListAsync(http.RequestAborted);
            var tinEvidenceCount = stagedDocuments.Count(item => item.Kind == "ftaTinScreenshot");
            var trnCertificateCount = stagedDocuments.Count(item => item.Kind == "trnCertificate");
            var tradeLicenseCount = stagedDocuments.Count(item => item.Kind == "tradeLicenseAttachment");
            if (tinEvidenceCount != 1 || tradeLicenseCount is < 1 or > 3 ||
                (request.IsVatRegistered == true && trnCertificateCount != 1) ||
                (request.IsVatRegistered == false && trnCertificateCount != 0))
                errors["documents"] = ["Upload the required TIN evidence, VAT certificate when registered, and one to three trade licenses."];

            if (tradeLicenseCount == 0)
                errors["tradeLicenseAttachment"] = ["Attach at least one trade license."];
            if (request.IsVatRegistered == true && trnCertificateCount == 0)
                errors["trnCertificate"] = ["Attach the VAT/TRN certificate when VAT registered."];
            if (request.IsVatRegistered == false && trnCertificateCount > 0)
                errors["trnCertificate"] = ["Do not attach a TRN certificate when the entity is not VAT registered."];
            if (errors.Count > 0)
            {
                Log.Warning("Resident submission validation failed. RequestId={RequestId} ErrorFieldCount={ErrorFieldCount}", http.TraceIdentifier, errors.Count);
                return Results.ValidationProblem(errors);
            }
            var submission = new CustomerSubmission
            {
                Id = Guid.NewGuid(),
                SCode = session.SCode,
                Hmy = customer.Hmy,
                TCode = customer.TCode,
                LegalEntityName = request.LegalEntityName!.Trim(),
                TinCiphertext = tinCrypto.Protect(request.Tin!.Trim()),
                TrnCiphertext = request.IsVatRegistered == true ? tinCrypto.Protect(request.Trn!.Trim()) : null,
                CustomerType = request.CustomerType!,
                IsVatRegistered = request.IsVatRegistered!.Value,
                TradeLicenseNumber = request.TradeLicenseNumber!.Trim().ToUpperInvariant(),
                TradeLicenseIssuingAuthority = request.TradeLicenseIssuingAuthority!.Trim(),
                RegisteredAddressLine1 = request.RegisteredAddressLine1!.Trim(),
                City = request.City!.Trim(),
                Emirate = NormalizeEmirate(request.Emirate)!,
                CountryCode = request.CountryCode!.Trim().ToUpperInvariant(),
                EInvoicingWave = request.EInvoicingWave!.Trim(),
                IsFreeZoneEntity = request.IsFreeZoneEntity!.Value,
                Status = SubmissionStatus.PendingReview,
                SubmittedAtUtc = DateTimeOffset.UtcNow
            };
            db.Submissions.Add(submission);
            foreach (var upload in stagedDocuments)
            {
                db.Documents.Add(new SubmissionDocument
                {
                    Id = Guid.NewGuid(),
                    SubmissionId = submission.Id,
                    Kind = upload.Kind == "tradeLicenseAttachment" && tradeLicenseCount > 1
                        ? $"tradeLicenseAttachment-{upload.Ordinal}" : upload.Kind,
                    ContentType = upload.ContentType,
                    Extension = upload.Extension,
                    Content = upload.Content,
                    UploadedAtUtc = upload.UploadedAtUtc
                });
            }
            customer.IsSubmitted = true;
            customer.DtUpdated = DateTimeOffset.UtcNow;
            db.StagedDocuments.RemoveRange(stagedDocuments);
            try
            {
                await db.SaveChangesAsync(http.RequestAborted);
            }
            catch (DbUpdateException)
            {
                if (await db.YardiCustomers.AsNoTracking().AnyAsync(item => item.Hmy == customer.Hmy && item.TCode == customer.TCode && item.IsSubmitted))
                    return Results.Conflict(new { error = "This customer has already submitted the information." });
                throw;
            }

            Log.Information("Resident submission committed. SubmissionId={SubmissionId}", submission.Id);
            return Results.Ok(new { message = "Your information was submitted successfully.", isSubmitted = true });
        }).RequireRateLimiting("customer-login");

        app.MapGet("/api/staff/submissions/pending", async (IntakeDbContext db, TinCrypto tinCrypto, HttpContext http) =>
        {
            if (!HasStaffKey(http, staffApiKey)) return Results.Unauthorized();
            var rows = await db.Submissions.AsNoTracking().Where(s => s.Status == SubmissionStatus.PendingReview)
                .OrderBy(s => s.SubmittedAtUtc)
                .Select(s => new
                {
                    s.Id,
                    s.SCode,
                    s.LegalEntityName,
                    s.TinCiphertext,
                    s.TradeLicenseNumber,
                    s.TrnCiphertext,
                    s.CustomerType,
                    s.IsVatRegistered,
                    s.TradeLicenseIssuingAuthority,
                    s.RegisteredAddressLine1,
                    s.City,
                    s.Emirate,
                    s.CountryCode,
                    s.EInvoicingWave,
                    s.IsFreeZoneEntity,
                    s.SubmittedAtUtc
                })
                .ToListAsync();
            var submissionIds = rows.Select(s => s.Id).ToArray();
            var documentRows = await db.Documents.AsNoTracking().Where(d => submissionIds.Contains(d.SubmissionId))
                .Select(d => new { d.SubmissionId, d.Kind }).ToListAsync();
            return Results.Ok(rows.Select(s => new
            {
                s.Id,
                s.SCode,
                s.LegalEntityName,
                Tin = tinCrypto.Unprotect(s.TinCiphertext),
                Trn = s.TrnCiphertext is null ? null : tinCrypto.Unprotect(s.TrnCiphertext),
                s.CustomerType,
                s.IsVatRegistered,
                s.TradeLicenseNumber,
                s.TradeLicenseIssuingAuthority,
                s.RegisteredAddressLine1,
                s.City,
                s.Emirate,
                s.CountryCode,
                s.EInvoicingWave,
                s.IsFreeZoneEntity,
                s.SubmittedAtUtc,
                Documents = documentRows.Where(d => d.SubmissionId == s.Id)
                    .Select(d => new { d.Kind, Url = $"/api/staff/submissions/{s.Id}/documents/{d.Kind}" })
            }));
        });

        app.MapGet("/api/staff/submissions/{id:guid}/documents/{kind}", async (Guid id, string kind, IntakeDbContext db, TinCrypto tinCrypto, HttpContext http) =>
        {
            if (!HasStaffKey(http, staffApiKey)) return Results.Unauthorized();
            if (kind is not ("ftaTinScreenshot" or "trnCertificate" or "tradeLicenseAttachment") &&
                !Regex.IsMatch(kind, @"^tradeLicenseAttachment-[1-3]$", RegexOptions.CultureInvariant)) return Results.NotFound();
            var document = await db.Documents.AsNoTracking().SingleOrDefaultAsync(x => x.SubmissionId == id && x.Kind == kind);
            if (document is null) return Results.NotFound();
            http.Response.Headers["Cache-Control"] = "no-store";
            return Results.File(tinCrypto.UnprotectBytes(document.Content), document.ContentType, $"{kind}{document.Extension}", enableRangeProcessing: false);
        });

        app.MapPost("/api/staff/submissions/{id:guid}/approve", async (Guid id, IntakeDbContext db, HttpContext http) =>
        {
            if (!HasStaffKey(http, staffApiKey)) return Results.Unauthorized();
            var item = await db.Submissions.SingleOrDefaultAsync(s => s.Id == id);
            if (item is null) return Results.NotFound();
            if (item.Status != SubmissionStatus.PendingReview) return Results.Conflict();
            item.Status = SubmissionStatus.Approved;
            item.ApprovedAtUtc = DateTimeOffset.UtcNow;
            item.ApprovedBy = "staff-key";
            await db.SaveChangesAsync();
            Log.Information("Submission approved. SubmissionId={SubmissionId}", item.Id);
            return Results.NoContent();
        });

        app.MapGet("/api/staff/export.csv", async (IntakeDbContext db, TinCrypto tinCrypto, HttpContext http) =>
        {
            if (!HasStaffKey(http, staffApiKey)) return Results.Unauthorized();
            var rows = await db.Submissions.AsNoTracking().Where(s => s.Status == SubmissionStatus.Approved)
                .OrderBy(s => s.ApprovedAtUtc).ToListAsync();
            var csv = new StringBuilder("SCode,LegalEntityName,CustomerType,VATRegistered,TIN,TRN,TradeLicenseNumber,TradeLicenseIssuingAuthority,RegisteredAddressLine1,City,Emirate,CountryCode,EInvoicingWave,IsFreeZoneEntity,SubmittedAtUtc\r\n");
            foreach (var row in rows)
                csv.AppendLine(string.Join(',', new[]
                {
            row.SCode, row.LegalEntityName, row.CustomerType, row.IsVatRegistered == true ? "Yes" : row.IsVatRegistered == false ? "No" : "",
            tinCrypto.Unprotect(row.TinCiphertext),
            row.TrnCiphertext is null ? "" : tinCrypto.Unprotect(row.TrnCiphertext), row.TradeLicenseNumber,
            row.TradeLicenseIssuingAuthority, row.RegisteredAddressLine1, row.City, row.Emirate,
            row.CountryCode, row.EInvoicingWave, row.IsFreeZoneEntity ? "Yes" : "No", row.SubmittedAtUtc.ToString("O")
                }.Select(CsvCell)));
            Log.Information("Approved submission export completed. RecordCount={RecordCount}", rows.Count);
            return Results.File(Encoding.UTF8.GetBytes(csv.ToString()), "text/csv; charset=utf-8", "approved-submissions.csv");
        });

        app.Run();

        static async Task<CustomerSession?> FindSessionAsync(HttpContext http, IntakeDbContext db)
        {
            http.Response.Headers["Cache-Control"] = "no-store";
            var token = http.Request.Cookies[CustomerSessionCookie];
            if (string.IsNullOrWhiteSpace(token)) return null;
            if (token.Length is < 30 or > 200) return null;
            var hash = TokenHash(token);
            var session = await db.CustomerSessions.SingleOrDefaultAsync(s => s.TokenHash == hash);
            if (session is null || session.RevokedAtUtc is not null || session.ExpiresAtUtc <= DateTimeOffset.UtcNow)
                return null;
            return await db.YardiCustomers.AnyAsync(customer => customer.Hmy == session.Hmy &&
                customer.TCode == session.TCode && !customer.IsExpired) ? session : null;
        }

        static async Task EnsureSqliteSchemaAsync(IntakeDbContext db)
        {
            await db.Database.OpenConnectionAsync();
            try
            {
                var connection = db.Database.GetDbConnection();
                await using var command = connection.CreateCommand();
                command.CommandText = "PRAGMA table_info('Submissions');";
                await using var reader = await command.ExecuteReaderAsync();
                var columns = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                while (await reader.ReadAsync()) columns.Add(reader.GetString(1));
                await reader.CloseAsync();

                if (!columns.Contains("TrnCiphertext")) await db.Database.ExecuteSqlRawAsync("ALTER TABLE Submissions ADD COLUMN TrnCiphertext TEXT NULL;");
                if (!columns.Contains("CustomerType")) await db.Database.ExecuteSqlRawAsync("ALTER TABLE Submissions ADD COLUMN CustomerType TEXT NOT NULL DEFAULT ''; ");
                if (!columns.Contains("IsVatRegistered")) await db.Database.ExecuteSqlRawAsync("ALTER TABLE Submissions ADD COLUMN IsVatRegistered INTEGER NULL;");
                await db.Database.ExecuteSqlRawAsync("CREATE TABLE IF NOT EXISTS SubmissionDocuments (Id TEXT NOT NULL PRIMARY KEY, SubmissionId TEXT NOT NULL, Kind TEXT NOT NULL, ContentType TEXT NOT NULL, Extension TEXT NOT NULL, Content BLOB NOT NULL, UploadedAtUtc TEXT NOT NULL, CONSTRAINT FK_SubmissionDocuments_Submissions FOREIGN KEY (SubmissionId) REFERENCES Submissions(Id) ON DELETE CASCADE);");
                await db.Database.ExecuteSqlRawAsync("CREATE UNIQUE INDEX IF NOT EXISTS IX_SubmissionDocuments_SubmissionId_Kind ON SubmissionDocuments(SubmissionId, Kind);");
            }
            finally { await db.Database.CloseConnectionAsync(); }
        }

        static bool HasStaffKey(HttpContext http, string expected)
        {
            var supplied = http.Request.Headers["X-Staff-Key"].ToString();
            if (supplied.Length < 32 || supplied.Length > 256) return false;
            return CryptographicOperations.FixedTimeEquals(
                SHA256.HashData(Encoding.UTF8.GetBytes(expected)),
                SHA256.HashData(Encoding.UTF8.GetBytes(supplied)));
        }

        static string TokenHash(string token) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
        static bool SecretEquals(string expected, string actual) => CryptographicOperations.FixedTimeEquals(
            SHA256.HashData(Encoding.UTF8.GetBytes(expected)), SHA256.HashData(Encoding.UTF8.GetBytes(actual)));
        static Dictionary<string, string[]> Validate(ResidentSubmissionRequest request)
        {
            var errors = new Dictionary<string, string[]>();
            if (!ValidRequiredText(request.LegalEntityName, 200))
                errors["legalEntityName"] = ["Enter a legal entity name up to 200 characters."];
            if (string.IsNullOrWhiteSpace(request.Tin) || !Regex.IsMatch(request.Tin.Trim(), @"^[0-9]{10}$", RegexOptions.CultureInvariant))
                errors["tin"] = ["Enter the 10-digit TIN format shown in your information request."];
            if (request.CustomerType is not ("Business" or "Government entity" or "Individual"))
                errors["customerType"] = ["Choose Business, Government entity, or Individual."];
            if (!request.IsVatRegistered.HasValue)
                errors["isVatRegistered"] = ["Select whether the entity is VAT registered."];
            if (request.IsVatRegistered == true && (string.IsNullOrWhiteSpace(request.Trn) || !Regex.IsMatch(request.Trn.Trim(), @"^[0-9]{15}$", RegexOptions.CultureInvariant)))
                errors["trn"] = ["Enter the 15-digit TRN for a VAT-registered entity."];
            if (request.IsVatRegistered == false && !string.IsNullOrWhiteSpace(request.Trn))
                errors["trn"] = ["Leave TRN blank when the entity is not VAT registered."];
            var licenseNumbers = request.TradeLicenseNumber?.Split([',', ';'], StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries) ?? [];
            if (licenseNumbers.Length is < 1 or > 3 || licenseNumbers.Any(number => !Regex.IsMatch(number, @"^[A-Za-z0-9][A-Za-z0-9/-]{2,31}$", RegexOptions.CultureInvariant)))
                errors["tradeLicenseNumber"] = ["Enter up to three trade license numbers, each using 3–32 letters, numbers, hyphens, or slashes."];
            if (!string.Equals(request.TradeLicenseIssuingAuthority?.Trim(), "UAE", StringComparison.Ordinal))
                errors["tradeLicenseIssuingAuthority"] = ["The trade license issuing authority is UAE."];
            if (!ValidRequiredText(request.RegisteredAddressLine1, 300))
                errors["registeredAddressLine1"] = ["Enter address line 1, up to 300 characters."];
            if (!ValidRequiredText(request.City, 100))
                errors["city"] = ["Enter a city up to 100 characters."];
            if (NormalizeEmirate(request.Emirate) is null)
                errors["emirate"] = ["Choose one of the seven UAE emirates."];
            if (!string.Equals(request.CountryCode?.Trim(), "AE", StringComparison.OrdinalIgnoreCase))
                errors["countryCode"] = ["The country code must be AE."];
            if (request.EInvoicingWave is not ("Wave 1" or "Wave 2"))
                errors["eInvoicingWave"] = ["Choose Wave 1 or Wave 2."];
            if (!request.IsFreeZoneEntity.HasValue)
                errors["isFreeZoneEntity"] = ["Select Yes or No."];
            return errors;
        }

        static bool ValidateUpload(IFormFile? file, bool required, out string contentType, out string extension, out string error)
        {
            contentType = "";
            extension = "";
            error = "";
            if (file is null || string.IsNullOrWhiteSpace(file.FileName) || file.Length == 0)
            {
                if (required) error = "Attach this required document.";
                return !required;
            }
            if (file.Length > 5 * 1024 * 1024)
            {
                error = "Each document must be 5 MB or smaller.";
                return false;
            }

            extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (extension is not (".pdf" or ".jpg" or ".jpeg" or ".png"))
            {
                error = "Only PDF, JPG, JPEG, and PNG files are allowed.";
                return false;
            }
            Span<byte> header = stackalloc byte[8];
            using (var stream = file.OpenReadStream())
            {
                var read = stream.Read(header);
                var isPdf = read >= 5 && header[..5].SequenceEqual("%PDF-"u8);
                var isJpeg = read >= 3 && header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF;
                var isPng = read >= 8 && header.SequenceEqual(new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A });
                if (isPdf && extension == ".pdf") contentType = "application/pdf";
                else if (isJpeg && extension is ".jpg" or ".jpeg") contentType = "image/jpeg";
                else if (isPng && extension == ".png") contentType = "image/png";
                else
                {
                    error = "The file content does not match its PDF, JPG, JPEG, or PNG extension.";
                    return false;
                }
            }
            return true;
        }

        static bool ValidRequiredText(string? value, int maxLength) =>
            !string.IsNullOrWhiteSpace(value) && value.Trim().Length <= maxLength && !value.Any(char.IsControl);

        static string? NormalizeEmirate(string? value) => value?.Trim().ToUpperInvariant() switch
        {
            "ABU DHABI" => "Abu Dhabi",
            "DUBAI" => "Dubai",
            "SHARJAH" => "Sharjah",
            "AJMAN" => "Ajman",
            "UMM AL QUWAIN" => "Umm Al Quwain",
            "RAS AL KHAIMAH" => "Ras Al Khaimah",
            "FUJAIRAH" => "Fujairah",
            _ => null
        };

        static string CsvCell(string value)
        {
            var firstMeaningfulCharacter = value.TrimStart(' ', '\t', '\r', '\n');
            var safe = firstMeaningfulCharacter.Length > 0 && firstMeaningfulCharacter[0] is '=' or '+' or '-' or '@' or '\t' or '\r' ? "'" + value : value;
            return "\"" + safe.Replace("\"", "\"\"") + "\"";
        }
    }
}
