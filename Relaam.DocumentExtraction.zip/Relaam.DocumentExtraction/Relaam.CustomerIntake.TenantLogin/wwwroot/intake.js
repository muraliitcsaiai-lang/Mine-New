"use strict";

const loginForm = document.querySelector("#login-form");
const intakeForm = document.querySelector("#intake-form");
const loginView = document.querySelector("#login-view");
const intakeView = document.querySelector("#intake-view");
const successView = document.querySelector("#success-view");
const message = document.querySelector("#message");
const formError = document.querySelector("#form-error");
const customerLoginName = document.querySelector("#customer-login-name");
const passwordInput = document.querySelector("#customer-password");
const extractedInformationSection = document.querySelector("#extracted-information-section");
const primaryFormActions = document.querySelector(".primary-form-actions");
function choiceValue(name) {
  return document.querySelector(`input[name="${name}"]:checked`)?.value || "";
}

const trnField = document.querySelector("#trn-field");
const trnInput = document.querySelector("#trn");
const trnDocumentField = document.querySelector("#trn-document-field");
const trnCertificateInput = document.querySelector("#trnCertificate");
const extractionStatus = document.querySelector("#extraction-status");
const extractButton = document.querySelector("#extract-button");
const requiredStatus = document.querySelector("#required-status");
const reviewPanel = document.querySelector("#review-panel");
const reviewSummary = document.querySelector("#review-summary");
const extractButtonLabel = extractButton.querySelector(".button-label");
const extractSpinner = extractButton.querySelector(".button-spinner");
const dirtyFields = new Set();
const allowedExtensions = new Set(["pdf", "jpg", "jpeg", "png"]);
const maxFileBytes = 5 * 1024 * 1024;
let isAuthenticated = false;
let currentTcode = "";
let customerType = "";
let currentCustomerName = "";
let stagedDocuments = [];
let uploadQueue = Promise.resolve();
let isSubmitted = false;
let extractionController = null;

function validateRequiredText(input) {
  const validate = () => input.setCustomValidity(input.value.trim() ? "" : "This field is required.");
  input.addEventListener("input", validate);
  input.addEventListener("change", validate);
  input.addEventListener("blur", validate);
  validate();
}

["legalEntityName", "tin", "tradeLicenseNumber",
  "tradeLicenseIssuingAuthority", "registeredAddressLine1", "city", "emirate", "countryCode", "eInvoicingWave"]
  .forEach(id => validateRequiredText(document.getElementById(id)));

document.querySelectorAll("#intake-form input:not([type=file]), #intake-form select").forEach(input => {
  input.addEventListener("input", () => { dirtyFields.add(input.name || input.id); updateRequiredStatus(); });
  input.addEventListener("change", () => { dirtyFields.add(input.name || input.id); updateRequiredStatus(); });
  input.addEventListener("blur", () => { input.dataset.touched = "true"; });
});

function updateVatFields() {
  const vatChoice = choiceValue("isVatRegistered");
  const registered = vatChoice === "true";
  const notRegistered = vatChoice === "false";
  trnField.hidden = notRegistered;
  // The VAT certificate must be selectable before extraction so the extractor can read it.
  trnDocumentField.hidden = notRegistered;
  trnInput.required = registered;
  trnCertificateInput.required = false;
  if (!registered) {
    trnInput.value = "";
    trnCertificateInput.value = "";
    dirtyFields.delete("trn");
    void deleteDocumentGroup("trnCertificate");
  }
    updateRequiredStatus();
    updateDocumentActions(); // refreshes “2 of 2” / “2 of 3”
}
document.querySelectorAll('input[name="isVatRegistered"]').forEach(input => input.addEventListener("change", updateVatFields));
updateVatFields();
setWorkflowActionsEnabled(false);
extractButton.disabled = true;
trnInput.addEventListener("input", () => trnInput.setCustomValidity(trnInput.value && !/^[0-9]{15}$/.test(trnInput.value) ? "Enter the 15-digit TRN shown on your VAT certificate." : ""));
const tradeLicenseNumberInput = document.querySelector("#tradeLicenseNumber");
function validateTradeLicenseNumbers() {
  const value = tradeLicenseNumberInput.value.trim();
  if (!value) {
    tradeLicenseNumberInput.setCustomValidity("Enter a trade license number.");
    return;
  }
  const numbers = value.split(/[,;]/).map(item => item.trim()).filter(Boolean);
  const valid = numbers.length >= 1 && numbers.length <= 3 &&
    numbers.every(item => /^[A-Za-z0-9][A-Za-z0-9/-]{2,31}$/.test(item));
  tradeLicenseNumberInput.setCustomValidity(valid
    ? ""
    : "Enter up to three license numbers, each using 3–32 letters, numbers, hyphens, or slashes, separated by commas.");
}
tradeLicenseNumberInput.addEventListener("input", validateTradeLicenseNumbers);

function validateFile(input) {
  if (input.type !== "file") return;
  const files = [...(input.files || [])];
  input.setCustomValidity("");
  if (input.id === "tradeLicenseAttachment" && files.length > 3) {
    input.setCustomValidity("Select no more than three trade licenses.");
    return;
  }
  const invalid = files.find(file => {
    const extension = file.name.split(".").pop().toLowerCase();
    return !allowedExtensions.has(extension) || file.size > maxFileBytes;
  });
  if (invalid) {
    const extension = invalid.name.split(".").pop().toLowerCase();
    input.setCustomValidity(!allowedExtensions.has(extension)
      ? "Only PDF, JPG, JPEG, and PNG files are allowed."
      : "Each document must be 5 MB or smaller.");
  }
}

function updateRequiredStatus() {
  const required = [...intakeForm.querySelectorAll("[required]")].filter(input => !input.closest("[hidden]"));
  const complete = required.filter(input => input.validity.valid).length;
  requiredStatus.textContent = `${complete} of ${required.length} required fields complete`;
}
function hasRequiredDocuments() {
  const has = kind => stagedDocuments.some(item => item.kind === kind);
  return has("ftaTinScreenshot") && has("tradeLicenseAttachment") &&
    (choiceValue("isVatRegistered") === "true" ? has("trnCertificate") :
      choiceValue("isVatRegistered") === "false" && !has("trnCertificate"));
}

function renderUploadedDocuments() {
  const container = document.querySelector("#uploaded-documents");
  container.replaceChildren();
  for (const file of stagedDocuments) {
    const row = document.createElement("div");
    row.className = "uploaded-document";
    const name = document.createElement("span");
    name.textContent = file.fileName;
    const view = document.createElement("a");
    view.href = `/api/resident/documents/${encodeURIComponent(file.id)}/view`;
    view.target = "_blank";
    view.rel = "noopener noreferrer";
    view.textContent = "View";
    row.append(name, view);
    container.append(row);
  }
}

function updateDocumentActions() {
    debugger;
  const registered = choiceValue("isVatRegistered") === "true";
  const required = registered ? 3 : 2;
  const complete = Number(stagedDocuments.some(item => item.kind === "ftaTinScreenshot")) +
    Number(stagedDocuments.some(item => item.kind === "tradeLicenseAttachment")) +
    Number(registered && stagedDocuments.some(item => item.kind === "trnCertificate"));
  if (isAuthenticated && !isSubmitted)
    extractionStatus.textContent = `${complete} of ${required} required document groups uploaded.`;
  extractButton.disabled = !isAuthenticated || isSubmitted || !hasRequiredDocuments();
  setWorkflowActionsEnabled(isAuthenticated && !isSubmitted && hasRequiredDocuments());
  updateRequiredStatus();
}

async function deleteDocumentGroup(kind) {
  if (!isAuthenticated || isSubmitted) return;
  try {
    const response = await fetch(`/api/resident/documents/${encodeURIComponent(kind)}`, {
      method: "DELETE", credentials: "same-origin", cache: "no-store"
    });
    if (response.ok) {
      stagedDocuments = stagedDocuments.filter(item => item.kind !== kind);
      renderUploadedDocuments();
    }
  } catch { /* Keep the prior staged file when the server cannot be reached. */ }
  updateDocumentActions();
}

async function uploadDocumentGroup(input) {
  if (!isAuthenticated || isSubmitted) return;
  validateFile(input);
  if (!input.files?.length) {
    await deleteDocumentGroup(input.name);
    return;
  }
  if (!input.reportValidity()) return;
  const body = new FormData();
  body.append("kind", input.name);
  [...input.files].forEach(file => body.append("files", file, file.name));
  input.disabled = true;
  extractButton.disabled = true;
  extractionStatus.textContent = "Uploading selected document(s)…";
  try {
    const response = await fetch("/api/resident/documents/upload", {
      method: "POST", body, credentials: "same-origin", cache: "no-store"
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      extractionStatus.textContent = result.error || "Document upload failed. Please retry.";
      input.value = "";
      return;
    }
    stagedDocuments = result.documents || [];
    renderUploadedDocuments();
    extractionStatus.textContent = result.sftpEnabled
      ? "Documents uploaded securely. You can now extract the information."
      : "Documents saved securely. You can now extract the information.";
  } catch {
    extractionStatus.textContent = "Document upload failed. Check your connection and retry.";
    input.value = "";
  } finally {
    input.disabled = isSubmitted;
    updateDocumentActions();
  }
}

document.querySelectorAll('#intake-form input[type="file"]').forEach(input => input.addEventListener("change", () => {
  uploadQueue = uploadQueue.then(() => uploadDocumentGroup(input));
}));

async function extractDocumentFields() {
  if (!isAuthenticated || isSubmitted) return;
  if (!hasRequiredDocuments()) {
    extractionStatus.textContent = "Upload all required documents before extracting information.";
    return;
  }

  extractionController?.abort();
  const controller = new AbortController();
  extractionController = controller;
  extractButton.disabled = true;
  setWorkflowActionsEnabled(false);
  extractButton.setAttribute("aria-busy", "true");
  extractSpinner.hidden = false;
  extractButtonLabel.textContent = "Reading your documents…";
  extractionStatus.textContent = "Reading your documents securely…";
  try {
    const response = await fetch("/api/resident/extract", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isVatRegistered: choiceValue("isVatRegistered") === "true" }),
      cache: "no-store",
      credentials: "same-origin",
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      revealCustomerFields();
      setWorkflowActionsEnabled(true);
      extractionStatus.textContent = "We could not read the documents right now. Your fields are available for manual entry. You can retry extraction or continue when ready.";
      return;
    }
    const fields = result.fields || {};
    const hasSuggestions = Object.values(fields).some(value =>
      typeof value === "boolean" || (typeof value === "string" && value.trim().length > 0));
    if (!hasSuggestions) {
      revealCustomerFields();
      setWorkflowActionsEnabled(true);
      extractionStatus.textContent = "No details could be read from these documents. You can enter the information manually, or retry with a clearer file.";
      return;
    }
    revealCustomerFields();
    applyExtractedFields(fields);
    document.querySelector("#tradeLicenseIssuingAuthority").value = "UAE";
    document.querySelector("#countryCode").value = "AE";
    setWorkflowActionsEnabled(true);
    updateRequiredStatus();
    extractionStatus.textContent = "Document suggestions added. Please check each value against your documents.";
  } catch (error) {
    if (error.name !== "AbortError") {
      revealCustomerFields();
      setWorkflowActionsEnabled(true);
      extractionStatus.textContent = "We could not reach the document reader. Your fields are available for manual entry. You can retry extraction or continue when ready.";
    }
  } finally {
    if (extractionController === controller) {
      extractButton.disabled = !hasRequiredDocuments() || isSubmitted;
      extractButton.removeAttribute("aria-busy");
      extractSpinner.hidden = true;
      extractButtonLabel.textContent = "Extract details from documents";
    }
  }
}

function setWorkflowActionsEnabled(enabled) {
  document.querySelector("#review-button").disabled = !enabled;
  document.querySelector("#submit-button").disabled = !enabled;
}

function applyExtractedFields(fields) {
  const textFieldMap = {
    legalEntityName: "legalEntityName",
    tin: "tin",
    trn: "trn",
    tradeLicenseNumber: "tradeLicenseNumber",
    registeredAddressLine1: "registeredAddressLine1",
    city: "city",
    emirate: "emirate",
  };
  for (const [property, id] of Object.entries(textFieldMap)) {
    const input = document.getElementById(id);
    const value = typeof fields[property] === "string" ? fields[property].trim() : "";
    if (value && !dirtyFields.has(id)) {
      input.value = value.slice(0, input.maxLength > 0 ? input.maxLength : 300);
      input.setCustomValidity(input.value.trim() ? "" : "This field is required.");
    }
  }
  if (typeof fields.customerType === "string" && !dirtyFields.has("customerType")) {
    const option = [...document.querySelectorAll('input[name="customerType"]')].find(input => input.value === fields.customerType);
    if (option) option.checked = true;
  }
  if (typeof fields.isVatRegistered === "boolean" && !dirtyFields.has("isVatRegistered")) {
    const option = [...document.querySelectorAll('input[name="isVatRegistered"]')].find(input => input.value === String(fields.isVatRegistered));
    if (option) option.checked = true;
    updateVatFields();
  }
  if (typeof fields.isFreeZoneEntity === "boolean" && !dirtyFields.has("isFreeZoneEntity")) {
    const option = [...document.querySelectorAll('input[name="isFreeZoneEntity"]')].find(input => input.value === String(fields.isFreeZoneEntity));
    if (option) option.checked = true;
  }
  if (typeof fields.eInvoicingWave === "string" && !dirtyFields.has("eInvoicingWave")) {
    const wave = document.querySelector("#eInvoicingWave");
    if ([...wave.options].some(option => option.value === fields.eInvoicingWave))
      wave.value = fields.eInvoicingWave;
  }
  validateTradeLicenseNumbers();
}

document.querySelectorAll('#intake-form input[type="file"]').forEach(input => {
  input.addEventListener("change", () => {
    validateFile(input);
    if (input.files?.length) extractionStatus.textContent = "Documents selected. Choose Extract details from documents to fill the form.";
    updateRequiredStatus();
  });
});
extractButton.addEventListener("click", extractDocumentFields);

function revealCustomerFields() {
  updateVatFields();
  primaryFormActions.hidden = false;
  updateRequiredStatus();
  extractedInformationSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function setReviewMode(isReviewing) {
  for (const selector of [".template-section", ".extract-row", ".primary-form-actions"]) {
    const element = intakeForm.querySelector(`:scope > ${selector}`);
    if (element) element.hidden = isReviewing;
  }
  reviewPanel.hidden = !isReviewing;
  if (!isReviewing) revealCustomerFields();
}

function fieldValue(id) {
  if (["customerType", "isVatRegistered", "isFreeZoneEntity"].includes(id)) {
    const value = choiceValue(id);
    if (id === "isVatRegistered" || id === "isFreeZoneEntity") return value === "true" ? "Yes" : value === "false" ? "No" : "";
    return value;
  }
  const element = document.getElementById(id);
  if (element.type === "file") return stagedDocuments.filter(file => file.kind === id).map(file => file.fileName).join(", ") || "-";
  if (element.tagName === "SELECT") return element.selectedOptions[0]?.textContent.trim() || "";
  return element.value.trim();
}

function showReview() {
  formError.hidden = true;
  if (!hasRequiredDocuments()) {
    formError.textContent = "Upload every required document before continuing.";
    formError.hidden = false;
    formError.focus();
    return;
  }
  validateTradeLicenseNumbers();
  const controls = [...intakeForm.querySelectorAll("input, select")].filter(input => !input.closest("[hidden]"));
  for (const control of controls) {
    control.dataset.touched = "true";
    validateFile(control);
    if (!control.reportValidity()) return;
  }
  const rows = [
    ["Customer type", "customerType"], ["Legal entity / customer name", "legalEntityName"],
    ["VAT registered", "isVatRegistered"], ["TIN", "tin"],
    ...(choiceValue("isVatRegistered") === "true" ? [["TRN", "trn"]] : []),
    ["Trade license number", "tradeLicenseNumber"], ["Issuing authority", "tradeLicenseIssuingAuthority"],
    ["Registered address", "registeredAddressLine1"], ["City", "city"], ["Emirate", "emirate"],
    ["Country code", "countryCode"], ["Free zone entity", "isFreeZoneEntity"], ["E-invoicing wave", "eInvoicingWave"],
    ["FTA TIN evidence", "ftaTinScreenshot"],
    ...(choiceValue("isVatRegistered") === "true" ? [["TRN certificate", "trnCertificate"]] : []),
    ["Trade license attachment(s)", "tradeLicenseAttachment"]
  ];
  reviewSummary.replaceChildren();
  for (const [label, id] of rows) {
    const wrapper = document.createElement("tr");
    const term = document.createElement("th");
    const detail = document.createElement("td");
    term.scope = "row";
    term.textContent = label;
    detail.textContent = fieldValue(id) || "—";
    wrapper.append(term, detail);
    reviewSummary.append(wrapper);
  }
  setReviewMode(true);
  document.querySelector("#review-title").focus();
  reviewPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

document.querySelector("#review-button").addEventListener("click", showReview);
document.querySelector("#back-to-edit-button").addEventListener("click", () => {
  setReviewMode(false);
  document.querySelector("#general-section-title").focus();
});

function displayCustomerName(name,customerType) {
  currentCustomerName = name || "";
    customerLoginName.value = currentCustomerName;
    setChoice("customerType", customerType);
    updateVatFields();
  //  setChoice("customerType", customerType);
  document.querySelector("#customer-display-name").textContent = currentCustomerName;
}

function setChoice(name, value) {
    const codeToLabel = {
        400: "Business",
        464: "Government entity",
        500: "Individual"
    };

    const selectedValue =
        name === "customerType"
            ? codeToLabel[Number(value)]
            : String(value ?? "");

    const option = [...document.querySelectorAll(`input[name="${name}"]`)]
        .find(input => input.value === String(selectedValue));

    if (option) option.checked = true;
}

function populateSavedFields(fields) {
  if (!fields) return;
  for (const id of ["legalEntityName", "tin", "trn", "tradeLicenseNumber", "tradeLicenseIssuingAuthority",
    "registeredAddressLine1", "city", "countryCode", "eInvoicingWave"]) {
    const input = document.getElementById(id);
    if (typeof fields[id] === "string") input.value = fields[id];
  }
  const setChoice = (name, value) => {
    const option = [...document.querySelectorAll(`input[name="${name}"]`)].find(input => input.value === String(value));
    if (option) option.checked = true;
  };
  setChoice("customerType", fields.customerType);
  setChoice("isVatRegistered", fields.isVatRegistered);
  setChoice("isFreeZoneEntity", fields.isFreeZoneEntity);
  const emirate = document.querySelector("#emirate");
  if ([...emirate.options].some(option => option.value === fields.emirate)) emirate.value = fields.emirate;
  updateVatFields();
  validateTradeLicenseNumbers();
}

function showSubmittedReadOnly() {
  isSubmitted = true;
  document.querySelector("#submitted-banner").hidden = false;
  document.querySelector(".extract-row").hidden = true;
  document.querySelector(".primary-form-actions").hidden = true;
  reviewPanel.hidden = true;
  for (const input of intakeForm.querySelectorAll("input, select, button")) input.disabled = true;
  document.querySelector("#tradeLicenseIssuingAuthority").value = "UAE";
  document.querySelector("#countryCode").value = "AE";
}

async function loadResidentState() {
  const response = await fetch("/api/resident/me", { credentials: "same-origin", cache: "no-store" });
  if (!response.ok) return false;
  const state = await response.json();
  isAuthenticated = true;
  isSubmitted = Boolean(state.isSubmitted);
  currentTcode = state.tcode;
    displayCustomerName(state.customerName, state.customerType);
  stagedDocuments = state.documents || [];
  renderUploadedDocuments();
  loginView.hidden = true;
  intakeView.hidden = false;
  if (isSubmitted) {
    populateSavedFields(state.fields);
    showSubmittedReadOnly();
    extractionStatus.textContent = "Submitted information and documents are available for viewing.";
  } else {
    document.querySelector("#submitted-banner").hidden = true;
    for (const input of intakeForm.querySelectorAll("input, select, button")) input.disabled = false;
    document.querySelector(".extract-row").hidden = false;
    document.querySelector(".primary-form-actions").hidden = false;
    updateVatFields();
    updateDocumentActions();
  }
  message.textContent = "";
  return true;
}

async function initializePage() {
    debugger;
  const linkedTcode = new URL(location.href).searchParams.get("tcode");
  history.replaceState(null, "", "/resident-login.html");
  if (linkedTcode && linkedTcode.length <= 100) {
    await fetch("/api/resident/logout", { method: "POST", credentials: "same-origin", cache: "no-store" }).catch(() => {});
    try {
      const response = await fetch("/api/resident/customer/lookup", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tcode: linkedTcode }), credentials: "same-origin", cache: "no-store"
      });
      const customer = await response.json().catch(() => ({}));
      if (!response.ok) {
        message.textContent = customer.error || "This customer link is invalid or expired. Contact the organization that sent it.";
        return;
      }
        currentTcode = customer.tcode;
        customerType = customer.CustomerType;
      displayCustomerName(customer.name);
    } catch {
      message.textContent = "We could not load this customer link. Check your connection and retry.";
    }
    return;
  }
  if (!(await loadResidentState())) message.textContent = "Open the customer link sent to you to sign in.";
}

void initializePage();

// The tcode is read once, then removed from the visible browser URL before any API request.

loginForm.addEventListener("submit", async event => {
  event.preventDefault();
  if (!currentTcode || !loginForm.reportValidity()) {
    message.textContent = "Open the customer link sent to you before signing in.";
    return;
  }
  message.textContent = "Signing in…";
    try {
        debugger;
    const response = await fetch("/api/resident/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tCode: currentTcode, password: passwordInput.value }),
      cache: "no-store",
      credentials: "same-origin"
    });
    passwordInput.value = "";
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      message.textContent = response.status === 429
        ? "Too many attempts. Please wait and try again."
        : "Sign-in failed. Check your details or contact the organization that sent the link.";
      return;
    }
    isAuthenticated = true;
    displayCustomerName(body.customerName);
    await loadResidentState();
    } catch (ex) {
        console.log(ex);
    passwordInput.value = "";
    message.textContent = "We could not sign in. Please try again.";
  }
});

intakeForm.addEventListener("submit", async event => {
  event.preventDefault();
  if (!isAuthenticated || isSubmitted) return;
  if (reviewPanel.hidden) {
    showReview();
    return;
  }
  formError.hidden = true;
  const submitButton = document.querySelector("#submit-button");
  submitButton.disabled = true;
  message.textContent = "Submitting…";
  try {
    const submissionBody = new FormData(intakeForm);
    for (const fileInput of intakeForm.querySelectorAll('input[type="file"]')) submissionBody.delete(fileInput.name);
    const response = await fetch("/api/resident/submissions", {
      method: "POST",
      body: submissionBody,
      cache: "no-store",
      credentials: "same-origin"
    });
    const body = await response.json().catch(() => ({}));
    if (response.ok) {
      await loadResidentState();
      document.querySelector("#submitted-banner").scrollIntoView({ behavior: "smooth", block: "center" });
      message.textContent = "";
      return;
    }
    if (response.status === 401) {
      isAuthenticated = false;
      intakeView.hidden = true;
      loginView.hidden = false;
      message.textContent = "Your session expired. Please sign in again.";
    } else if (response.status === 409) {
      await loadResidentState();
    } else if (body.errors) {
      setReviewMode(false);
      const firstField = Object.keys(body.errors)[0];
      const control = intakeForm.elements.namedItem(firstField);
      formError.textContent = Object.values(body.errors).flat().join(" ") || "Please check the information and try again.";
      formError.hidden = false;
      (control || formError).focus();
      formError.scrollIntoView({ behavior: "smooth", block: "center" });
    } else {
      formError.textContent = body.error || "Information could not be submitted.";
      setReviewMode(false);
      formError.hidden = false;
      formError.focus();
    }
  } catch {
    formError.textContent = "We could not submit your information. Please try again.";
    setReviewMode(false);
    formError.hidden = false;
    formError.focus();
  } finally {
    submitButton.disabled = isSubmitted || !hasRequiredDocuments();
  }
});
