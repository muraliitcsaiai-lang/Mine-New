/*
UAT ONLY. Do not run in the production Yardi database.
Creates a separate directory database with one synthetic login for end-to-end testing.
The HMY value below is public test data and must never be used for a real resident.
*/
IF DB_ID(N'RelaamResidentDirectoryUat') IS NULL
    EXEC(N'CREATE DATABASE RelaamResidentDirectoryUat;');
GO

USE RelaamResidentDirectoryUat;
GO

IF OBJECT_ID(N'dbo.ResidentCredentials', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ResidentCredentials
    (
        SCode nvarchar(100) NOT NULL CONSTRAINT PK_ResidentCredentials PRIMARY KEY,
        Hmy nvarchar(512) NOT NULL,
        IsActive bit NOT NULL CONSTRAINT DF_ResidentCredentials_IsActive DEFAULT (1)
    );
END;
GO

IF OBJECT_ID(N'dbo.ResidentLoginDirectory', N'V') IS NULL
    EXEC(N'CREATE VIEW dbo.ResidentLoginDirectory AS SELECT SCode, Hmy, IsActive FROM dbo.ResidentCredentials;');
GO

IF OBJECT_ID(N'dbo.VerifyResidentCredential', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.VerifyResidentCredential @SCode nvarchar(100), @Hmy nvarchar(512) AS BEGIN SET NOCOUNT ON; SELECT CAST(CASE WHEN EXISTS (SELECT 1 FROM dbo.ResidentLoginDirectory WHERE SCode = @SCode AND Hmy = @Hmy AND IsActive = 1) THEN 1 ELSE 0 END AS bit) AS IsValid; END;');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.ResidentCredentials WHERE SCode = N'demo1')
BEGIN
    INSERT dbo.ResidentCredentials (SCode, Hmy, IsActive)
    VALUES (N'demo1', N'demo1', 1);
END;
GO

/* Grant this permission to the dedicated application database user only:
GRANT EXECUTE ON OBJECT::dbo.VerifyResidentCredential TO [<application-database-user>];
*/
