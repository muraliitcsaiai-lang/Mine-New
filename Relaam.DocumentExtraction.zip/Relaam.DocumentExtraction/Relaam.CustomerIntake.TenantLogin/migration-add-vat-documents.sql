/* Apply once to an existing intake database before deploying the updated app. */
ALTER TABLE dbo.Submissions ADD
    TrnCiphertext nvarchar(300) NULL,
    CustomerType nvarchar(30) NOT NULL CONSTRAINT DF_Submissions_CustomerType DEFAULT (N''),
    IsVatRegistered bit NULL;
GO

CREATE TABLE dbo.SubmissionDocuments
(
    Id uniqueidentifier NOT NULL CONSTRAINT PK_SubmissionDocuments PRIMARY KEY,
    SubmissionId uniqueidentifier NOT NULL,
    Kind nvarchar(30) NOT NULL,
    ContentType nvarchar(50) NOT NULL,
    Extension nvarchar(5) NOT NULL,
    Content varbinary(max) NOT NULL,
    UploadedAtUtc datetimeoffset NOT NULL,
    CONSTRAINT FK_SubmissionDocuments_Submissions FOREIGN KEY (SubmissionId)
        REFERENCES dbo.Submissions(Id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IX_SubmissionDocuments_SubmissionId_Kind ON dbo.SubmissionDocuments(SubmissionId, Kind);
GO
