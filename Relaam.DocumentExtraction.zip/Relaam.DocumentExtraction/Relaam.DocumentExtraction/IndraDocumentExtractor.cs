﻿using System.Text;
using System.Text.RegularExpressions;
using Indra.Ocr.Images;
using Indra.Ocr.Onnx;
using Indra.Ocr.Pdf;
using Indra.Ocr.Pipeline;

namespace Relaam.DocumentExtraction;

/// <summary>
/// Runs local Indra OCR on PDF, JPEG, and PNG customer documents,
/// then extracts the fields used by the customer intake form.
/// </summary>
public sealed class IndraDocumentExtractor : IDocumentExtractor, IDisposable
{
    private const int MaxDocumentBytes = 5 * 1024 * 1024;
    private const int MaxDocuments = 5;
    private const int MaxPdfPagesPerDocument = 10;

    private static readonly RegexOptions RegexFlags =
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;

    private readonly OrtOcr _ocr;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private bool _disposed;

    public IndraDocumentExtractor(string? modelDirectory = null, int threads = 4)
    {
        var models = ModelFolder.Resolve(path: modelDirectory, math: false);
        _ocr = new OrtOcr(models, threads: threads);
    }

    public bool IsConfigured => true;
    public string Model => "Indra OCR local";

    public async Task<ExtractedDocumentFields> ExtractAsync(
        IReadOnlyCollection<UploadedDocument> documents,
        CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (documents.Count is < 1 or > MaxDocuments)
            throw new ArgumentException(
                $"Provide one to {MaxDocuments} documents.",
                nameof(documents));

        await _gate.WaitAsync(cancellationToken);

        var tempDirectory = Path.Combine(
            Path.GetTempPath(),
            "Relaam.DocumentExtraction",
            Guid.NewGuid().ToString("N"));

        try
        {
            Directory.CreateDirectory(tempDirectory);
            var recognized = new List<RecognizedDocument>(documents.Count);
            var documentIndex = 0;

            foreach (var document in documents)
            {
                cancellationToken.ThrowIfCancellationRequested();
                ValidateDocument(document);

                var extension = document.Extension.ToLowerInvariant();
                var path = Path.Combine(
                    tempDirectory,
                    $"document-{documentIndex++}{extension}");

                await File.WriteAllBytesAsync(
                    path,
                    document.Content,
                    cancellationToken);

                var text = document.ContentType == "application/pdf"
                    ? ReadPdf(path, cancellationToken)
                    : ReadImage(path, cancellationToken);

                recognized.Add(new RecognizedDocument(document, text));
            }

            return OcrFieldParser.Parse(recognized);
        }
        finally
        {
            try { Directory.Delete(tempDirectory, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }

            _gate.Release();
        }
    }

    private string ReadPdf(string path, CancellationToken cancellationToken)
    {
        var converter = new PdfConverter(_ocr, dpi: 200, mode: "auto");
        using var pdf = PdfConverter.Open(path, password: null);

        var pages = new List<string>();
        var pageCount = Math.Min(pdf.PageCount, MaxPdfPagesPerDocument);

        for (var pageIndex = 0; pageIndex < pageCount; pageIndex++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var page = converter.ConvertPage(pdf, pageIndex);
            pages.Add(page.Markdown ?? page.Text ?? "");
        }

        return string.Join(Environment.NewLine, pages);
    }

    private string ReadImage(string path, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        var converter = new ImageConverter(_ocr);
        var pages = new List<string>();

        foreach ((int _, OcrPage page) in converter.ConvertFrames(path))
        {
            cancellationToken.ThrowIfCancellationRequested();
            pages.Add(page.Markdown ?? page.Text ?? "");
        }

        return string.Join(Environment.NewLine, pages);
    }

    private static void ValidateDocument(UploadedDocument document)
    {
        if (document.Content is null ||
            document.Content.Length is 0 or > MaxDocumentBytes)
        {
            throw new ArgumentException(
                "Each document must be between 1 byte and 5 MB.",
                nameof(document));
        }

        var extension = document.Extension.ToLowerInvariant();
        var bytes = document.Content;

        var valid = extension switch
        {
            ".pdf" =>
                document.ContentType == "application/pdf" &&
                bytes.AsSpan().StartsWith("%PDF-"u8),

            ".jpg" or ".jpeg" =>
                document.ContentType == "image/jpeg" &&
                bytes.Length >= 3 &&
                bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[2] == 0xff,

            ".png" =>
                document.ContentType == "image/png" &&
                bytes.AsSpan().StartsWith(
                    new byte[] { 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a }),

            _ => false
        };

        if (!valid)
            throw new ArgumentException(
                "Document type or file signature is invalid.",
                nameof(document));
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _ocr.Dispose();
        _gate.Dispose();
    }


    internal sealed record RecognizedDocument(UploadedDocument Document, string Text);

    internal static class OcrFieldParser
    {
        private const RegexOptions Options =
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;

        private const string EmiratePattern =
            @"\b(Abu\s+Dhabi|Dubai|Sharjah|Ajman|Umm\s+Al\s+Quwain|Ras\s+Al\s+Khaimah|Fujairah)\b";

        private const string FieldLabelPattern =
            @"(?:Tax\s+Registration\s+Number|Tax\s+Identification\s+Number|\bTRN\b|\bTIN\b|" +
            @"Full\s+English\s+Legal\s+Name|Legal\s+Name\s+of\s+Entity|Trade\s+Name|" +
            @"Company\s+Name|Licensee|Registered\s+Address|Address|City|Emirate|" +
            @"Trade\s+License|Trading\s+License|Trade\s+Licence|Licence\s+No|" +
            @"License\s+No|License\s+Number|Licence\s+Number|Issuing\s+Authority|" +
            @"License\s+Issuing\s+Authority|Issue\s+Date|Expiry\s+Date)";

        public static ExtractedDocumentFields Parse(
            IReadOnlyCollection<RecognizedDocument> documents)
        {
            var vatDocs = documents
                .Where(item => item.Document.Kind == "trnCertificate")
                .ToArray();

            var tinDocs = documents
                .Where(item => item.Document.Kind == "ftaTinScreenshot")
                .ToArray();

            var licenseDocs = documents
                .Where(item => item.Document.Kind == "tradeLicenseAttachment")
                .ToArray();

            var allText = string.Join(
                Environment.NewLine,
                documents.Select(item => item.Text));

            // FTA certificate label is "Tax Registration Number".
            var trn = vatDocs
                .Select(item => MatchLabeledDigits(
                    item.Text,
                    @"(?:Tax\s+Registration\s+Number|\bTRN\b|VAT\s+Registration\s+Number)",
                    15,
                    15))
                .FirstOrDefault(value => value is not null);

            // Prefer an explicitly labeled TIN. If it is absent, UAE TIN is
            // the first ten digits of the 15-digit TRN.
            var tin = tinDocs
                .Select(item => MatchLabeledDigits(
                    item.Text,
                    @"(?:Tax\s+Identification\s+Number|\bTIN\b)",
                    10,
                    10))
                .FirstOrDefault(value => value is not null)
                ?? (trn is { Length: 15 } ? trn[..10] : null);

            var licenseNumbers = licenseDocs
                .Select(item => MatchLabeledLicenseNumber(item.Text))
                .Where(value => value is not null)
                .Select(value => value!)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(3)
                .ToArray();

            // UAE FTA VAT certificate label: "Legal Name of Entity (English)".
            var legalName =
                FirstLabeledText(
                    vatDocs.Select(item => item.Text),
                    @"Legal\s+Name\s+of\s+Entity\s*\(\s*English\s*\)",
                    200)
                ?? FirstLabeledText(
                    licenseDocs.Select(item => item.Text),
                    @"Trade\s+Name",
                    200);

            // License address is preferred; the VAT certificate address is fallback.
            var address =
                FirstLabeledText(
                    licenseDocs.Select(item => item.Text),
                    @"(?:Registered\s+)?Address",
                    300)
                ?? FirstLabeledText(
                    vatDocs.Select(item => item.Text),
                    @"The\s+Registered\s+Address\s+and\s+Contact\s+Number",
                    300);

            var authorityAndEmirate = DetectIssuer(allText);
            var emirate = authorityAndEmirate.Emirate
                ?? FindEmirate(string.Join(Environment.NewLine, licenseDocs.Select(item => item.Text)));

            var city = FirstLabeledText(
                    licenseDocs.Select(item => item.Text),
                    @"\bCity\b",
                    100)
                ?? emirate;

            var freeZone = Regex.IsMatch(
                allText,
                @"\b(?:FZE|FZ-LLC|Free\s+Zone\s+(?:Company|Establishment))\b",
                Options)
                ? true
                : (bool?)null;

            var customerType =
                Regex.IsMatch(allText, @"\b(?:Government|Government\s+Entity)\b", Options)
                    ? "Government entity"
                    : Regex.IsMatch(
                        allText,
                        @"\b(?:L\.?L\.?C\.?|Limited\s+Liability|FZE|FZ-LLC|PJSC|Company|Establishment)\b",
                        Options)
                        ? "Business"
                        : null;

            return new ExtractedDocumentFields(
                CustomerType: customerType,
                LegalEntityName: legalName,
                Tin: tin,
                Trn: trn,
                TradeLicenseNumber: licenseNumbers.Length == 0
                    ? null
                    : string.Join(", ", licenseNumbers),

                // Your current submission validation expects this value to be "UAE".
                // Keep the actual issuing department in a separate field if you add one.
                TradeLicenseIssuingAuthority: licenseDocs.Length > 0 ? "UAE" : null,

                RegisteredAddressLine1: address,
                City: city,
                Emirate: emirate,
                CountryCode: "AE",
                IsVatRegistered: trn is not null ? true : null,
                IsFreeZoneEntity: freeZone,
                EInvoicingWave: null);
        }

        private static string? MatchLabeledDigits(
            string text,
            string labelPattern,
            int minimumDigits,
            int maximumDigits)
        {
            var lines = text.Split(
                ['\r', '\n'],
                StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            for (var i = 0; i < lines.Length; i++)
            {
                var label = Regex.Match(lines[i], labelPattern, Options);
                if (!label.Success) continue;

                var candidate = new StringBuilder(
                    lines[i][(label.Index + label.Length)..]);

                for (var j = i + 1; j < Math.Min(lines.Length, i + 3); j++)
                {
                    if (Regex.IsMatch(lines[j], FieldLabelPattern, Options)) break;
                    candidate.Append(' ').Append(lines[j]);
                }

                var pattern =
                    $@"(?<!\d)\d(?:[\s.\-/]?\d){{{minimumDigits - 1},{maximumDigits - 1}}}(?!\d)";

                foreach (Match match in Regex.Matches(candidate.ToString(), pattern, Options))
                {
                    var digits = Regex.Replace(match.Value, @"\D", "");
                    if (digits.Length >= minimumDigits && digits.Length <= maximumDigits)
                        return digits;
                }
            }

            return null;
        }

        private static string? MatchLabeledLicenseNumber(string text)
        {
            var lines = text.Split(
                ['\r', '\n'],
                StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            const string labelPattern =
                @"(?:(?:Trade|Trading|Economic|Commercial)\s+)?Licen[cs]e\s*(?:No\.?|Number|#)";

            foreach (var line in lines)
            {
                var label = Regex.Match(line, labelPattern, Options);
                if (!label.Success) continue;

                var remainder = line[(label.Index + label.Length)..];
                var value = Regex.Match(
                    remainder,
                    @"(?<![A-Z0-9])[A-Z]{0,5}[-/]?\d[A-Z0-9/-]{2,31}(?![A-Z0-9])",
                    Options);

                if (value.Success)
                    return value.Value.Trim('-', '/');
            }

            return null;
        }

        private static string? FirstLabeledText(
            IEnumerable<string> sources,
            string labelPattern,
            int maxLength)
        {
            foreach (var source in sources)
            {
                var lines = source.Split(
                    ['\r', '\n'],
                    StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

                for (var i = 0; i < lines.Length; i++)
                {
                    var label = Regex.Match(lines[i], labelPattern, Options);
                    if (!label.Success) continue;

                    var value = Clean(lines[i][(label.Index + label.Length)..], maxLength);

                    if (value is null)
                    {
                        for (var j = i + 1; j < Math.Min(lines.Length, i + 4); j++)
                        {
                            if (Regex.IsMatch(lines[j], FieldLabelPattern, Options)) break;

                            value = Clean(lines[j], maxLength);
                            if (value is not null) break;
                        }
                    }

                    if (value is not null) return value;
                }
            }

            return null;
        }

        private static string? Clean(string value, int maxLength)
        {
            value = Regex.Replace(value, @"\s+", " ")
                .Trim(' ', ':', '|', '-', '.', ';', ',');

            if (value.Length < 2) return null;
            if (Regex.IsMatch(value, @"^[\d\W_]+$", Options)) return null;

            var nextLabel = Regex.Match(value, FieldLabelPattern, Options);
            if (nextLabel.Success && nextLabel.Index > 0)
                value = value[..nextLabel.Index].Trim(' ', ':', '|', '-', '.', ';', ',');

            if (value.Length < 2) return null;
            return value[..Math.Min(value.Length, maxLength)];
        }

        private static (string? Authority, string? Emirate) DetectIssuer(string text)
        {
            if (Regex.IsMatch(text, @"Government\s+of\s+Ajman|Ajman\s+Department\s+of\s+Economic\s+Development", Options))
                return ("Ajman Department of Economic Development", "Ajman");

            if (Regex.IsMatch(text, @"ADRA|Abu\s+Dhabi\s+Registration\s+Authority", Options))
                return ("Abu Dhabi Registration Authority", "Abu Dhabi");

            if (Regex.IsMatch(text, @"Government\s+of\s+Sharjah|Sharjah\s+Economic\s+Development\s+Department", Options))
                return ("Sharjah Economic Development Department", "Sharjah");

            if (Regex.IsMatch(text, @"Dubai\s+Department\s+of\s+Economy|Dubai\s+Economy\s+and\s+Tourism", Options))
                return ("Dubai Department of Economy and Tourism", "Dubai");

            return (null, null);
        }

        private static string? FindEmirate(string text)
        {
            var match = Regex.Match(text, EmiratePattern, Options);
            if (!match.Success) return null;

            return Regex.Replace(match.Groups[1].Value, @"\s+", " ") switch
            {
                var value when value.Equals("abu dhabi", StringComparison.OrdinalIgnoreCase) => "Abu Dhabi",
                var value when value.Equals("umm al quwain", StringComparison.OrdinalIgnoreCase) => "Umm Al Quwain",
                var value when value.Equals("ras al khaimah", StringComparison.OrdinalIgnoreCase) => "Ras Al Khaimah",
                var value => char.ToUpperInvariant(value[0]) + value[1..].ToLowerInvariant()
            };
        }
    }
}