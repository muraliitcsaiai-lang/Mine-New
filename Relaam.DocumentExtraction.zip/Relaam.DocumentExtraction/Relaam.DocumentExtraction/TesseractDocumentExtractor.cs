using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace Relaam.DocumentExtraction;

/// <summary>Runs local Tesseract OCR and Poppler PDF rendering; uploaded files stay on the host.</summary>
public sealed class TesseractDocumentExtractor(
    string tesseractExecutable,
    string pdfToImageExecutable,
    string? tessdataDirectory = null,
    string languages = "eng") : IDocumentExtractor
{
    // Customer uploads are expected to be single-page documents; ignore later PDF pages.
    private const int MaxPdfPages = 1;
    private const int MaxDocuments = 5;
    private static readonly TimeSpan ProcessTimeout = TimeSpan.FromSeconds(45);
    private readonly SemaphoreSlim _gate = new(1, 1);

    public bool TesseractAvailable => ResolveExecutable(tesseractExecutable) is not null;
    public bool PdfRendererAvailable => ResolveExecutable(pdfToImageExecutable) is not null;
    public bool IsConfigured => TesseractAvailable && PdfRendererAvailable;
    public string Model => "Tesseract 5 local OCR";

    public async Task<ExtractedDocumentFields> ExtractAsync(
        IReadOnlyCollection<UploadedDocument> documents,
        CancellationToken cancellationToken = default)
    {
        if (!IsConfigured)
            throw new InvalidOperationException("Configure the Tesseract and PDF rendering executables for local OCR.");
        if (documents.Count is < 1 or > MaxDocuments)
            throw new ArgumentException($"Provide one to {MaxDocuments} documents.", nameof(documents));

        await _gate.WaitAsync(cancellationToken);
        var tempDirectory = Path.Combine(Path.GetTempPath(), "Relaam.DocumentExtraction", Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tempDirectory);
            var recognizedDocuments = new List<RecognizedDocument>(documents.Count);
            var index = 0;
            foreach (var document in documents)
            {
                cancellationToken.ThrowIfCancellationRequested();
                ValidateDocument(document);
                var inputPath = Path.Combine(tempDirectory, $"document-{index++}{document.Extension.ToLowerInvariant()}");
                await File.WriteAllBytesAsync(inputPath, document.Content, cancellationToken);
                var documentText = new StringBuilder();
                string numericOcrPath;

                if (document.ContentType == "application/pdf")
                {
                    var imagePrefix = Path.Combine(tempDirectory, $"page-{index}");
                    await RunProcessAsync(ResolveExecutable(pdfToImageExecutable)!,
                        ["-f", "1", "-l", MaxPdfPages.ToString(), "-r", "200", "-png", inputPath, imagePrefix],
                        $"PDF rendering for {document.Kind}", cancellationToken);
                    var pages = Directory.EnumerateFiles(tempDirectory, $"page-{index}-*.png")
                        .OrderBy(path => path, StringComparer.Ordinal).Take(MaxPdfPages).ToArray();
                    if (pages.Length == 0) throw new InvalidOperationException("The PDF renderer returned no pages.");
                    numericOcrPath = pages[0];
                    for (var pageIndex = 0; pageIndex < pages.Length; pageIndex++)
                        documentText.AppendLine(await RecognizeImageAsync(
                            pages[pageIndex], $"{document.Kind} PDF page {pageIndex + 1} OCR", cancellationToken));
                }
                else
                {
                    numericOcrPath = inputPath;
                    documentText.AppendLine(await RecognizeImageAsync(
                        inputPath, $"{document.Kind} image OCR", cancellationToken));
                }

                string? numericText = null;
                if (document.Kind == "trnCertificate")
                {
                    // FTA certificates use a dense bilingual layout. A separate
                    // digits-only pass reduces lost digits in the TRN field.
                    numericText = await RecognizeImageAsync(numericOcrPath, "TRN number OCR", cancellationToken,
                        pageSegmentationMode: 11, digitsOnly: true);
                }
                recognizedDocuments.Add(new RecognizedDocument(document, documentText.ToString(), numericText));
            }

            return OcrFieldParser.Parse(recognizedDocuments);
        }
        finally
        {
            try { Directory.Delete(tempDirectory, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
            _gate.Release();
        }
    }

    private async Task<string> RecognizeImageAsync(
        string imagePath,
        string operationName,
        CancellationToken cancellationToken,
        int pageSegmentationMode = 11,
        bool digitsOnly = false)
    {
        var arguments = new List<string> { imagePath, "stdout", "-l", languages, "--oem", "1", "--psm", pageSegmentationMode.ToString() };
        if (digitsOnly) arguments.AddRange(["-c", "tessedit_char_whitelist=0123456789"]);
        if (!string.IsNullOrWhiteSpace(tessdataDirectory))
        {
            arguments.Add("--tessdata-dir");
            arguments.Add(tessdataDirectory);
        }
        return await RunProcessAsync(ResolveExecutable(tesseractExecutable)!, arguments, operationName, cancellationToken);
    }

    private static async Task<string> RunProcessAsync(
        string executable,
        IEnumerable<string> arguments,
        string operationName,
        CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = executable,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        foreach (var argument in arguments) startInfo.ArgumentList.Add(argument);

        using var process = new Process { StartInfo = startInfo };
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(ProcessTimeout);
        try
        {
            if (!process.Start()) throw new InvalidOperationException("The local document reader could not be started.");
            var outputTask = process.StandardOutput.ReadToEndAsync(timeout.Token);
            var errorTask = process.StandardError.ReadToEndAsync(timeout.Token);
            await process.WaitForExitAsync(timeout.Token);
            var output = await outputTask;
            _ = await errorTask; // Drain native diagnostics without logging document data or paths.
            if (process.ExitCode != 0) throw new InvalidOperationException("The local document reader could not read the selected file.");
            if (output.Length > 1_000_000) throw new InvalidOperationException("OCR output exceeded the allowed size.");
            return output;
        }
        catch (OperationCanceledException)
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); }
            catch (InvalidOperationException) { }
            if (!cancellationToken.IsCancellationRequested)
                throw new TimeoutException($"{operationName} exceeded its {ProcessTimeout.TotalSeconds:0}-second processing limit.");
            throw;
        }
    }

    private static string? ResolveExecutable(string executable)
    {
        if (string.IsNullOrWhiteSpace(executable)) return null;
        if (Path.IsPathRooted(executable) || executable.Contains(Path.DirectorySeparatorChar) || executable.Contains(Path.AltDirectorySeparatorChar))
            return File.Exists(executable) ? executable : null;

        var extensions = OperatingSystem.IsWindows()
            ? (Environment.GetEnvironmentVariable("PATHEXT") ?? ".EXE;.CMD;.BAT").Split(';', StringSplitOptions.RemoveEmptyEntries)
            : [""];
        foreach (var directory in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        foreach (var extension in extensions)
        {
            var candidate = Path.Combine(directory, executable);
            if (!Path.HasExtension(candidate)) candidate += extension;
            if (File.Exists(candidate)) return candidate;
        }
        return null;
    }

    private static void ValidateDocument(UploadedDocument document)
    {
        var extension = document.Extension.ToLowerInvariant();
        var bytes = document.Content;
        var valid = extension switch
        {
            ".pdf" => document.ContentType == "application/pdf" && bytes.AsSpan().StartsWith("%PDF-"u8),
            ".jpg" or ".jpeg" => document.ContentType == "image/jpeg" && bytes.Length >= 3 && bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[2] == 0xff,
            ".png" => document.ContentType == "image/png" && bytes.AsSpan().StartsWith(new byte[] { 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a }),
            _ => false
        };
        if (!valid) throw new ArgumentException("Document type or signature is invalid.", nameof(document));
    }
}

internal sealed record RecognizedDocument(UploadedDocument Document, string Text, string? NumericText = null);

internal static class OcrFieldParser
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    private const string EmiratePattern = @"\b(Abu\s+Dhabi|Dubai|Sharjah|Ajman|Umm\s+Al\s+Quwain|Ras\s+Al\s+Khaimah|Fujairah)\b";
    private const string FieldLabelPattern = @"(?:Tax\s+Registration\s+Number|Tax\s+Identification\s+Number|TRN|TIN|Full\s+English\s+Legal\s+Name|Legal\s+Name\s+of\s+Entity\s*(?:\(\s*English\s*\)|English)|Company\s+Name|Legal\s+Name|Trade\s+Name|Business\s+Name|Address|City|Emirate|Trade\s+License|Trade\s+Licence|Economic\s+Licence|Economic\s+License|Licen[cs]e\s*(?:No\.?|Number|#)|Legal\s+Form|Free\s*Zone|E-?Invoicing\s+Wave)";

    public static ExtractedDocumentFields Parse(IReadOnlyCollection<RecognizedDocument> documents)
    {
        var licenseDocs = documents.Where(item => item.Document.Kind == "tradeLicenseAttachment").ToArray();
        var primaryLicenseText = licenseDocs.FirstOrDefault()?.Text ?? "";
        var allText = string.Join(Environment.NewLine, documents.Select(item => item.Text));
        var tin = documents.Where(item => item.Document.Kind == "ftaTinScreenshot")
            .Select(item => MatchLabeledNumber(item.Text, @"(?:\bTIN\b|Tax\s+Identification\s+Number)", 10))
            .FirstOrDefault(value => value is not null)
            ?? licenseDocs.Select(item => MatchLabeledNumber(item.Text, @"(?:\bTIN\b|Tax\s+Identification\s+Number)", 10))
                .FirstOrDefault(value => value is not null);
        var trnDocuments = documents.ToArray();
        var trn = trnDocuments.Select(item => MatchLabeledNumber(item.Text,
                @"(?:\bTRN\b|Tax\s+Registration\s+Number|VAT\s+Registration\s+Number)", 15))
            .FirstOrDefault(value => value is not null);
        trn ??= trnDocuments.Where(item => item.Document.Kind == "trnCertificate")
            .Select(item => MatchFixedLengthNumber(item.NumericText, 15))
            .FirstOrDefault(value => value is not null);
        var licenseNumbers = licenseDocs.Select(item => MatchLicenseNumber(item.Text))
            .Where(value => value is not null)
            .Select(value => value!)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(3)
            .ToArray();

        const string englishLegalNamePattern = @"(?:Full\s+English\s+Legal\s+Name|Legal\s+Name\s+of\s+Entity\s*(?:\(\s*English\s*\)|English)|Legal\s+Name\s*\(\s*English\s*\))";
        const string anyLegalNamePattern = @"(?:Company\s+Name|Legal\s+(?:Entity\s+)?Name|Trade\s+Name|Business\s+Name|Name\s+of\s+(?:the\s+)?(?:Registrant|Taxable\s+Person|Licensee))";
        var legalName = FirstLabeledText(documents.Where(item => item.Document.Kind == "trnCertificate").Select(item => item.Text),
                englishLegalNamePattern, 200)
            ?? FirstLabeledText(licenseDocs.Select(item => item.Text),
                $@"{englishLegalNamePattern}|{anyLegalNamePattern}", 200);
        var address = FirstLabeledText(licenseDocs.Select(item => item.Text),
            @"(?:Registered\s+|Business\s+)?Address(?:\s+Line\s*1)?", 300);
        var emirate = FirstEmirate(primaryLicenseText);
        var city = FirstLabeledText(licenseDocs.Select(item => item.Text), @"\bCity\b", 100) ?? emirate;
        var freeZone = MatchBoolean(allText, @"Free\s*Zone\s*(?:Entity)?\s*[:|]?\s*(Yes|No|True|False)");
        if (freeZone is null && Regex.IsMatch(primaryLicenseText, @"\b(?:FZE|FZ-LLC|Free\s+Zone\s+Establishment)\b", Options))
            freeZone = true;
        var customerType = MatchChoice(allText, @"(?:Customer|Entity)\s+Type\s*[:|]?\s*(Business|Government\s+entity|Individual)")
            ?? (Regex.IsMatch($"{legalName} {primaryLicenseText}", @"\b(?:L\.?L\.?C\.?|Limited\s+Liability|FZE|FZ-LLC|PJSC|Establishment|Company)\b", Options)
                ? "Business"
                : null);
        var wave = MatchChoice(allText, @"(?:E-?Invoicing\s+)?Wave\s*[:|]?\s*(Wave\s*[12])");

        return new ExtractedDocumentFields(
            CustomerType: customerType,
            LegalEntityName: legalName,
            Tin: tin,
            Trn: trn,
            TradeLicenseNumber: licenseNumbers.Length == 0 ? null : string.Join(", ", licenseNumbers),
            TradeLicenseIssuingAuthority: licenseDocs.Length > 0 ? "UAE" : null,
            RegisteredAddressLine1: address,
            City: city,
            Emirate: emirate,
            CountryCode: "AE",
            IsVatRegistered: trn is not null || documents.Any(item => item.Document.Kind == "trnCertificate") ? true : null,
            IsFreeZoneEntity: freeZone,
            EInvoicingWave: wave);
    }

    private static string? MatchLabeledNumber(string text, string labelPattern, int minimumDigits, int maximumDigits = -1)
    {
        if (maximumDigits < 0) maximumDigits = minimumDigits;
        var lines = text.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        for (var lineIndex = 0; lineIndex < lines.Length; lineIndex++)
        {
            var match = Regex.Match(lines[lineIndex], labelPattern, Options);
            if (!match.Success) continue;
            var candidate = new StringBuilder(lines[lineIndex][(match.Index + match.Length)..]);
            for (var nextIndex = lineIndex + 1; nextIndex < Math.Min(lines.Length, lineIndex + 3); nextIndex++)
            {
                if (Regex.IsMatch(lines[nextIndex], FieldLabelPattern, Options)) break;
                candidate.Append(' ').Append(lines[nextIndex]);
            }
            var digitPattern = $@"(?<!\d)\d(?:[\s.\-/]?\d){{{minimumDigits - 1},{maximumDigits - 1}}}(?!\d)";
            foreach (Match digitMatch in Regex.Matches(candidate.ToString(), digitPattern, Options))
            {
                var digits = Regex.Replace(digitMatch.Value, @"\D", "");
                if (digits.Length >= minimumDigits && digits.Length <= maximumDigits)
                    return digits;
            }
        }
        return null;
    }

    private static string? MatchFixedLengthNumber(string? text, int digitCount)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var candidates = Regex.Matches(text, @"(?<![0-9])[0-9]+(?![0-9])", Options)
            .Select(match => match.Value)
            .Where(value => value.Length == digitCount)
            .Distinct(StringComparer.Ordinal)
            .ToArray();

        // Dates and reference numbers can also occur on an FTA certificate. Only
        // accept an unambiguous exact-length candidate; ambiguous results stay blank.
        return candidates.Length == 1 ? candidates[0] : null;
    }

    private static string? MatchLicenseNumber(string text)
    {
        var lines = text.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        const string labelPattern = @"(?:(?:Trade|Economic|Commercial)\s+)?Licen[cs]e\s*(?:No\.?|Number|#)";
        for (var lineIndex = 0; lineIndex < lines.Length; lineIndex++)
        {
            var label = Regex.Match(lines[lineIndex], labelPattern, Options);
            if (!label.Success) continue;
            var candidate = new StringBuilder(lines[lineIndex][(label.Index + label.Length)..]);
            for (var nextIndex = lineIndex + 1; nextIndex < Math.Min(lines.Length, lineIndex + 3); nextIndex++)
            {
                if (Regex.IsMatch(lines[nextIndex], FieldLabelPattern, Options)) break;
                candidate.Append(' ').Append(lines[nextIndex]);
            }
            var value = Regex.Match(candidate.ToString(), @"(?<![A-Z0-9])(?:[A-Z]{1,5}[-/]?)?\d[A-Z0-9/-]{2,31}(?![A-Z0-9])", Options);
            if (value.Success) return value.Value.Trim('-', '/');
        }
        return null;
    }

    private static string? FirstLabeledText(IEnumerable<string> sources, string labelPattern, int maxLength)
    {
        foreach (var source in sources)
        {
            var lines = source.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            for (var lineIndex = 0; lineIndex < lines.Length; lineIndex++)
            {
                var match = Regex.Match(lines[lineIndex], labelPattern, Options);
                if (!match.Success) continue;
                var value = CleanCandidate(lines[lineIndex][(match.Index + match.Length)..], maxLength);
                if (value is null || Regex.IsMatch(value, @"^(?:No\.?|Number|Date|Name|Address|City|Emirate|Yes|No)$", Options))
                {
                    for (var nextIndex = lineIndex + 1; nextIndex < Math.Min(lines.Length, lineIndex + 3); nextIndex++)
                    {
                        if (Regex.IsMatch(lines[nextIndex], FieldLabelPattern, Options)) break;
                        value = CleanCandidate(lines[nextIndex], maxLength);
                        if (value is not null) break;
                    }
                }
                if (value is not null) return value;
            }
        }
        return null;
    }

    private static string? CleanCandidate(string value, int maxLength)
    {
        value = Regex.Replace(value, @"\s+", " ").Trim(' ', ':', '|', '-', '.', ';', ',');
        var nextLabel = Regex.Match(value, FieldLabelPattern, Options);
        if (nextLabel.Success && nextLabel.Index > 0) value = value[..nextLabel.Index].Trim(' ', ':', '|', '-', '.', ';', ',');
        if (value.Length < 2 || Regex.IsMatch(value, @"^(?:[\d\W_]+)$", Options)) return null;
        return value[..Math.Min(value.Length, maxLength)];
    }

    private static string? FirstEmirate(string text)
    {
        var value = Regex.Match(text, EmiratePattern, Options).Groups[1].Value;
        return value.Length == 0 ? null : Regex.Replace(value, @"\s+", " ");
    }

    private static string? MatchChoice(string text, string pattern)
    {
        var match = Regex.Match(text, pattern, Options);
        return match.Success ? Regex.Replace(match.Groups[1].Value.Trim(), @"\s{2,}", " ") : null;
    }

    private static bool? MatchBoolean(string text, string pattern) => MatchChoice(text, pattern)?.ToLowerInvariant() switch
    {
        "yes" or "true" => true,
        "no" or "false" => false,
        _ => null
    };
}
