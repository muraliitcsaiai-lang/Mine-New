namespace Relaam.DocumentExtraction;

public sealed record UploadedDocument(string Kind, string ContentType, string Extension, byte[] Content);

public sealed record ExtractedDocumentFields(
    string? CustomerType,
    string? LegalEntityName,
    string? Tin,
    string? Trn,
    string? TradeLicenseNumber,
    string? TradeLicenseIssuingAuthority,
    string? RegisteredAddressLine1,
    string? City,
    string? Emirate,
    string? CountryCode,
    bool? IsVatRegistered,
    bool? IsFreeZoneEntity,
    string? EInvoicingWave);

public sealed record OpenAiDocumentExtractionOptions(string? ApiKey, string Model = "gpt-5.4-mini");

public interface IDocumentExtractor
{
    bool IsConfigured { get; }
    string Model { get; }
    Task<ExtractedDocumentFields> ExtractAsync(IReadOnlyCollection<UploadedDocument> documents, CancellationToken cancellationToken = default);
}

public sealed class DocumentExtractionException(int statusCode) : Exception("Document extraction failed.")
{
    public int StatusCode { get; } = statusCode;
}
